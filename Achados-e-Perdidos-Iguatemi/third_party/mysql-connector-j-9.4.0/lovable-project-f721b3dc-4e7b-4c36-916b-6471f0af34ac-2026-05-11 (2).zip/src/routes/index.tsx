import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { CinematicBg, Particles } from "@/components/cinematic-bg";
import { JobCard } from "@/components/job-card";
import { BrandMark } from "@/components/brand-mark";
import { jobs, companies } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Byte — Contrate engenheiros de elite em 48h. Zero custo de recrutamento." },
      { name: "description", content: "Cadeiras vazias custam $90.000/mês. A Byte elimina a linha de despesa do recrutamento e entrega 3 talentos sêniores LATAM, prontos em 48h. Risco zero." },
    ],
  }),
  component: HomePage,
});

const ease = [0.22, 1, 0.36, 1] as const;

function HomePage() {
  const featured = jobs.slice(0, 6);
  const featuredCompanies = companies.slice(0, 6);

  return (
    <div className="relative">
      {/* ============ HERO ============ */}
      <section className="relative min-h-[92vh] overflow-hidden">
        <CinematicBg />
        <Particles count={70} />

        {/* Extra cinematic flares */}
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute left-1/2 top-[58%] -translate-x-1/2 h-[420px] w-[1200px] rounded-full bg-primary/20 blur-[140px] opacity-60" />
          <div className="absolute right-[8%] top-[18%] h-[260px] w-[260px] rounded-full bg-primary-glow/30 blur-[90px] animate-pulse-slow" />
          {/* horizontal scanline */}
          <div className="absolute inset-x-0 top-[68%] h-px bg-gradient-to-r from-transparent via-primary-glow/40 to-transparent" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 sm:pt-20 pb-28">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease }}
            className="inline-flex items-center gap-3 rounded-full glass-card px-4 py-1.5 text-[11px] font-mono uppercase tracking-[0.22em]"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary-glow opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary-glow" />
            </span>
            <span className="text-primary-glow">framework de velocidade</span>
            <span className="text-muted-foreground">recrutamento tech · latam</span>
          </motion.div>

          {/* Headline asymmetric */}
          <div className="mt-10 grid lg:grid-cols-12 gap-10 items-end">
            <motion.h1
              initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, ease, delay: 0.1 }}
              className="lg:col-span-9 font-display text-foreground"
              style={{
                fontSize: "clamp(2.75rem, 7.2vw, 6.25rem)",
                lineHeight: 0.96,
                letterSpacing: "-0.035em",
              }}
            >
              <span className="block text-gradient">Cadeira vazia</span>
              <span className="block">
                não é vaga aberta. É{" "}
                <span className="font-display-soft text-gradient-iris">runway queimando.</span>
              </span>
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.9, ease, delay: 0.4 }}
              className="lg:col-span-3 lg:pb-2"
            >
              <div className="rounded-2xl glass-card p-5 border-iris">
                <div className="eyebrow mb-2">manifesto</div>
                <p className="text-sm text-foreground/85 leading-relaxed">
                  Não vendemos custo menor. Eliminamos a linha de despesa. Você só paga quando o talento produz.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Subhead */}
          <motion.p
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease, delay: 0.35 }}
            className="mt-8 max-w-2xl text-base sm:text-lg text-foreground/70 leading-relaxed"
          >
            3 candidatos pré-validados em 48 horas. Engenheiros sêniores LATAM, mesmo timezone, fluência total — entregando mais por menos. <span className="text-foreground/90">Sem comissão. Sem taxa. Sem prisão jurídica.</span>
          </motion.p>

          {/* Search bar — large, asymmetric */}
          <motion.div
            initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease, delay: 0.5 }}
            className="mt-12 max-w-4xl"
          >
            <div className="relative rounded-2xl glass-strong border-iris p-2 shadow-elevated">
              <div className="flex flex-col sm:flex-row items-stretch gap-2">
                <div className="flex-1 flex items-center gap-3 px-4 py-3">
                  <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary-glow shrink-0" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
                  </svg>
                  <input
                    placeholder="Staff Engineer, ML, Platform, SRE…"
                    className="flex-1 bg-transparent outline-none text-base placeholder:text-muted-foreground"
                  />
                </div>
                <div className="hidden sm:block w-px bg-white/10 my-2" />
                <div className="flex items-center gap-3 px-4 py-3">
                  <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary-glow shrink-0" fill="none" stroke="currentColor" strokeWidth={1.8}>
                    <path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7Z" /><circle cx="12" cy="9" r="2.5" />
                  </svg>
                  <input placeholder="Cidade ou Remoto" className="bg-transparent outline-none text-base placeholder:text-muted-foreground w-full sm:w-44" />
                </div>
                <Link
                  to="/jobs"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-iris px-6 py-3 text-sm font-medium text-white shadow-glow transition-transform hover:scale-[1.02]"
                >
                  Buscar
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
                </Link>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-mono">
              <span className="text-muted-foreground uppercase tracking-[0.2em] mr-1 self-center">trending:</span>
              {["React", "Rust", "LLMs", "Staff Engineer", "Design Systems", "Kubernetes"].map((t) => (
                <button
                  key={t}
                  className="px-3 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-primary/15 hover:border-primary/30 text-foreground/80 hover:text-foreground transition-all"
                >
                  {t}
                </button>
              ))}
            </div>
          </motion.div>

          {/* KPI strip */}
          <motion.div
            initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease, delay: 0.7 }}
            className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-x-10 gap-y-8 border-t border-white/5 pt-10"
          >
            {[
              ["48h", "para 3 candidatos prontos"],
              ["97%", "do ruído eliminado"],
              ["+18%", "retenção vs mercado"],
              ["$0", "custo de recrutamento"],
            ].map(([n, l]) => (
              <div key={l} className="relative">
                <div className="font-numeric text-4xl lg:text-5xl text-foreground">{n}</div>
                <div className="mt-2 eyebrow">{l}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Bottom fade */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-background" />
      </section>

      {/* ============ FEATURED JOBS ============ */}
      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-6 mb-12">
            <div>
              <div className="eyebrow mb-3">vagas em destaque</div>
              <h2 className="font-display text-5xl lg:text-6xl tracking-tight text-foreground">
                Posições que estão <span className="italic text-gradient-iris">sangrando roadmap</span>
              </h2>
            </div>
            <Link to="/jobs" className="hidden sm:inline-flex items-center gap-2 text-sm text-foreground/80 hover:text-foreground transition-colors">
              Ver todas as vagas
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {featured.map((j, i) => (
              <motion.div
                key={j.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.6, ease, delay: i * 0.06 }}
              >
                <JobCard job={j} index={i} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ COMPANIES MARQUEE ============ */}
      <section className="relative py-20 overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-10">
          <div className="flex items-end justify-between gap-6">
            <div>
              <div className="eyebrow mb-3">empresas que escalam com a byte</div>
              <h2 className="font-display text-5xl lg:text-6xl tracking-tight text-foreground">
                Times que pararam de <span className="italic text-gradient-iris">queimar runway</span>
              </h2>
            </div>
            <Link to="/companies" className="hidden sm:inline-flex items-center gap-2 text-sm text-foreground/80 hover:text-foreground">
              Ver todas
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
            </Link>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {featuredCompanies.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, ease, delay: i * 0.06 }}
            >
              <Link
                to="/companies/$companyId"
                params={{ companyId: c.id }}
                className="group block relative rounded-3xl glass-card border-iris hover-lift p-6 overflow-hidden"
                style={{ transform: i % 3 === 1 ? "translateY(1rem)" : undefined }}
              >
                <div
                  className="absolute -top-12 -right-12 h-40 w-40 rounded-full opacity-50 blur-3xl group-hover:opacity-90 transition-opacity"
                  style={{ background: c.accent }}
                />
                <div className="relative flex items-start gap-4">
                  <BrandMark initials={c.initials} accent={c.accent} size="lg" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-medium text-foreground truncate">{c.name}</h3>
                      {c.verified && <Verified />}
                    </div>
                    <div className="mt-1 text-[12px] text-muted-foreground">{c.industry} · {c.location}</div>
                    <p className="mt-3 text-sm text-foreground/80 line-clamp-2">{c.about}</p>
                    <div className="mt-4 flex items-center gap-3 text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
                      <span><span className="text-primary-glow">{c.openJobs}</span> vagas</span>
                      <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
                      <span>{c.size} pessoas</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ============ KANBAN PREVIEW ============ */}
      <section className="relative py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-5">
              <div className="eyebrow mb-3">máquina de entrega · 5 estágios</div>
              <h2 className="font-display text-5xl lg:text-6xl tracking-tight text-foreground">
                Pipeline cirúrgico. <span className="italic text-gradient-iris">3 candidatos.</span> Não 50.
              </h2>
              <p className="mt-6 text-foreground/75 text-lg leading-relaxed max-w-md">
                Imersão profunda → curadoria ativa → validação rigorosa → 3 finalistas em 48h → suporte contínuo. 97% do ruído eliminado antes de chegar no seu CTO.
              </p>
              <div className="mt-8 flex gap-3">
                <Link to="/dashboard/company" className="inline-flex items-center gap-2 rounded-full bg-gradient-iris px-5 py-2.5 text-sm font-medium text-white shadow-glow">
                  Ver pipeline ao vivo
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
                </Link>
                <Link to="/post-job" className="inline-flex items-center rounded-full glass-card border border-white/10 px-5 py-2.5 text-sm text-foreground hover:bg-white/5">
                  Publicar vaga
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7 relative">
              <div className="absolute -inset-8 rounded-3xl bg-primary/10 blur-3xl" />
              <div className="relative rounded-3xl glass-strong border-iris p-4 shadow-elevated overflow-hidden">
                <div className="flex gap-3 overflow-x-auto scrollbar-thin pb-2">
                  {[
                    ["Aplicado", 12, "oklch(0.7 0.05 258)"],
                    ["Triagem", 7, "oklch(0.7 0.13 230)"],
                    ["Entrevista", 4, "oklch(0.65 0.18 280)"],
                    ["Proposta", 2, "oklch(0.78 0.16 75)"],
                  ].map(([label, count, tint], idx) => (
                    <div key={label as string} className="min-w-[200px] rounded-2xl bg-white/[0.03] border border-white/5 p-3">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.18em]" style={{ color: tint as string }}>
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: tint as string }} />
                          {label}
                        </div>
                        <span className="text-[11px] text-muted-foreground font-mono">{count}</span>
                      </div>
                      <div className="space-y-2">
                        {Array.from({ length: idx === 0 ? 3 : 2 }).map((_, k) => (
                          <div key={k} className="rounded-xl bg-surface-2 p-3 border border-white/5 shadow-soft" style={{ transform: `rotate(${(k % 2 ? 0.6 : -0.4)}deg)` }}>
                            <div className="flex items-center gap-2">
                              <div className="h-7 w-7 rounded-full bg-gradient-iris" />
                              <div className="flex-1">
                                <div className="h-2 w-3/4 rounded-full bg-white/15" />
                                <div className="mt-1.5 h-1.5 w-1/2 rounded-full bg-white/10" />
                              </div>
                            </div>
                            <div className="mt-3 flex gap-1">
                              <div className="h-1.5 w-8 rounded-full bg-primary/60" />
                              <div className="h-1.5 w-6 rounded-full bg-white/10" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ DUAL CTA ============ */}
      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-6">
          <CtaCard
            eyebrow="para talentos latam"
            title="Ganhe em dólar. Trabalhe no seu timezone."
            body="Empresas de elite contratando direto. Sem intermediário cobrando do seu salário. Perfil pré-validado, ofertas que chegam prontas."
            cta="Entrar no pool"
            to="/signup/candidate"
          />
          <CtaCard
            eyebrow="para ctos e fundadores"
            title="Pare de queimar runway em cadeiras vazias."
            body="3 candidatos sêniores em 48h. SHIELD cobre reposição. RADAR previne turnover. Você só paga quando produz."
            cta="Agendar descoberta · 15 min"
            to="/signup/company"
            variant="filled"
          />
        </div>
      </section>
    </div>
  );
}

function Verified() {
  return (
    <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-primary-glow/20 text-primary-glow">
      <svg viewBox="0 0 24 24" className="h-2.5 w-2.5" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    </span>
  );
}

function CtaCard({
  eyebrow, title, body, cta, to, variant = "outline",
}: { eyebrow: string; title: string; body: string; cta: string; to: string; variant?: "outline" | "filled" }) {
  return (
    <Link
      to={to}
      className={`group relative overflow-hidden rounded-3xl border-iris p-10 hover-lift block ${
        variant === "filled" ? "bg-gradient-iris" : "glass-card"
      }`}
    >
      <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-primary/30 blur-3xl group-hover:bg-primary/50 transition-colors" />
      <div className="relative">
        <div className={`text-[10px] font-mono uppercase tracking-[0.22em] ${variant === "filled" ? "text-white/80" : "text-primary-glow"}`}>{eyebrow}</div>
        <h3 className={`mt-4 font-display text-4xl tracking-tight ${variant === "filled" ? "text-white" : "text-foreground"}`}>{title}</h3>
        <p className={`mt-3 max-w-md text-sm ${variant === "filled" ? "text-white/85" : "text-foreground/75"}`}>{body}</p>
        <div className={`mt-8 inline-flex items-center gap-2 text-sm font-medium ${variant === "filled" ? "text-white" : "text-foreground"}`}>
          {cta}
          <svg viewBox="0 0 24 24" className="h-4 w-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
        </div>
      </div>
    </Link>
  );
}
