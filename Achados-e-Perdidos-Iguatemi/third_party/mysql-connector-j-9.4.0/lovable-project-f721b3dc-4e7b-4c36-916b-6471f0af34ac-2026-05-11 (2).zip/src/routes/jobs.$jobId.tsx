import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { BrandMark } from "@/components/brand-mark";
import { JobCard } from "@/components/job-card";
import { JobCover } from "@/components/job-cover";
import { getCompany, getJob, jobs } from "@/lib/mock-data";

export const Route = createFileRoute("/jobs/$jobId")({
  loader: ({ params }) => {
    const job = getJob(params.jobId);
    if (!job) throw notFound();
    return { job, company: getCompany(job.companyId) };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.job.title} — ${loaderData.job.company}` : "Vaga" },
      { name: "description", content: loaderData?.job.description ?? "" },
    ],
  }),
  notFoundComponent: () => (
    <div className="min-h-[60vh] grid place-items-center px-6 text-center">
      <div>
        <div className="eyebrow mb-3">404</div>
        <h1 className="font-display text-5xl">Vaga não encontrada</h1>
        <Link to="/jobs" className="mt-6 inline-flex items-center rounded-full bg-gradient-iris px-5 py-2.5 text-sm text-white">Ver todas as vagas</Link>
      </div>
    </div>
  ),
  component: JobDetail,
});

function JobDetail() {
  const { job, company } = Route.useLoaderData();
  const related = jobs.filter((j) => j.id !== job.id && (j.area === job.area || j.companyId === job.companyId)).slice(0, 3);

  return (
    <div className="relative">
      <AmbientBg />

      {/* Cinematic cover */}
      <JobCover job={job} company={company ? { initials: company.initials, accent: company.accent, verified: company.verified } : undefined} />

      {/* Body */}
      <section className="relative pt-10 pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-8 space-y-12">
            <Block eyebrow="sobre a vaga" title="Contexto">
              <p className="text-foreground/85 leading-relaxed text-lg">{job.description}</p>
            </Block>

            <Block eyebrow="o que você fará" title="Responsabilidades">
              <ul className="space-y-3">
                {job.responsibilities.map((r: string, i: number) => (
                  <li key={i} className="flex gap-4 group">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary-glow group-hover:scale-150 transition-transform" />
                    <span className="text-foreground/90">{r}</span>
                  </li>
                ))}
              </ul>
            </Block>

            <Block eyebrow="o que esperamos" title="Requisitos">
              <ul className="space-y-3">
                {job.requirements.map((r: string, i: number) => (
                  <li key={i} className="flex gap-4">
                    <span className="font-mono text-[11px] text-primary-glow mt-1.5">0{i + 1}</span>
                    <span className="text-foreground/90">{r}</span>
                  </li>
                ))}
              </ul>
            </Block>

            <Block eyebrow="stack" title="Tecnologias">
              <div className="flex flex-wrap gap-2">
                {job.tags.map((t: string) => (
                  <span key={t} className="text-[12px] font-mono px-3 py-1.5 rounded-md glass-card border border-white/5 text-foreground/85">{t}</span>
                ))}
              </div>
            </Block>

            <Block eyebrow="o que você ganha" title="Benefícios">
              <div className="grid sm:grid-cols-2 gap-3">
                {job.benefits.map((b: string, i: number) => (
                  <div key={i} className="rounded-2xl glass-card border border-white/5 p-4 text-sm text-foreground/90 hover-lift">
                    {b}
                  </div>
                ))}
              </div>
            </Block>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-6 lg:sticky lg:top-24">
            <div className="rounded-3xl glass-strong border-iris p-6 shadow-elevated">
              <div className="eyebrow">faixa salarial</div>
              <div className="mt-2 font-numeric text-4xl text-gradient-iris">{job.salary}</div>
              <div className="mt-1 text-xs text-muted-foreground">/ mês · CLT ou PJ</div>

              <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
                <Stat label="Aplicantes" value={String(job.applicants)} />
                <Stat label="Visualizações" value={String(job.views)} />
                <Stat label="Publicada" value={job.postedAt} />
                <Stat label="Status" value={job.status} accent />
              </div>

              <Link
                to="/apply/$jobId" params={{ jobId: job.id }}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-iris py-3.5 text-sm font-medium text-white shadow-glow hover:scale-[1.01] transition-transform"
              >
                Candidatar-se a esta vaga
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7"/></svg>
              </Link>
              <button className="mt-2 w-full text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors py-2">
                salvar para depois
              </button>
            </div>

            {company && (
              <div className="rounded-3xl glass-card border-iris p-6 hover-lift">
                <div className="eyebrow mb-3">a empresa</div>
                <div className="flex items-start gap-4">
                  <BrandMark initials={company.initials} accent={company.accent} size="lg" />
                  <div className="min-w-0">
                    <h3 className="text-xl font-medium text-foreground">{company.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{company.industry} · {company.size} pessoas</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-foreground/80 leading-relaxed">{company.about}</p>
                <Link to="/companies/$companyId" params={{ companyId: company.id }} className="mt-5 inline-flex items-center gap-2 text-sm text-primary-glow hover:text-foreground transition-colors">
                  Ver página da empresa
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                </Link>
              </div>
            )}
          </aside>
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="relative pb-32">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="eyebrow mb-3">vagas relacionadas</div>
            <h2 className="font-display text-4xl tracking-tight mb-8">Você também pode gostar de</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {related.map((j, i) => <JobCard key={j.id} job={j} index={i} />)}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="text-[12px] px-3 py-1 rounded-full glass-card border border-white/5 text-foreground/85">{children}</span>;
}
function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/5 p-3">
      <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">{label}</div>
      <div className={`mt-1 text-sm font-medium ${accent ? "text-success" : "text-foreground"}`}>{value}</div>
    </div>
  );
}
function Block({ eyebrow, title, children }: { eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="eyebrow mb-2">{eyebrow}</div>
      <h2 className="font-display text-3xl tracking-tight mb-5">{title}</h2>
      {children}
    </div>
  );
}
