import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { applications, candidates, getJob, jobs, STAGES, type PipelineStage } from "@/lib/mock-data";

export const Route = createFileRoute("/dashboard/company/")({
  head: () => ({ meta: [{ title: "Painel da empresa — bluestack" }] }),
  component: CompanyDashboard,
});

const company = { name: "Nebula Tech", initials: "NT" };

function CompanyDashboard() {
  const myJobs = jobs.filter((j) => j.companyId === "c1");
  const myApps = applications.filter((a) => myJobs.some((j) => j.id === a.jobId));
  const totalApps = myApps.length;
  const inFunnel = myApps.filter((a) => !["hired", "rejected"].includes(a.stage)).length;
  const hired = myApps.filter((a) => a.stage === "hired").length;
  const conversionRate = totalApps > 0 ? Math.round((hired / totalApps) * 100) : 0;

  return (
    <div className="relative">
      <AmbientBg />
      <section className="relative pt-16 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-6 items-end">
            <div className="lg:col-span-8">
              <div className="eyebrow mb-2">painel · empresa</div>
              <h1 className="font-display text-5xl lg:text-6xl tracking-tight">Olá, <span className="italic text-gradient-iris">{company.name}</span></h1>
              <p className="mt-3 text-muted-foreground">Visão consolidada do seu pipeline de contratação.</p>
            </div>
            <Link to="/post-job" className="lg:col-span-4 lg:justify-self-end inline-flex items-center justify-center gap-2 rounded-full bg-gradient-iris px-6 py-3 text-sm font-medium text-white shadow-glow">
              Publicar nova vaga
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 5v14M5 12h14" /></svg>
            </Link>
          </div>

          {/* KPIs */}
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Kpi label="Vagas ativas" value={String(myJobs.filter((j) => j.status === "Ativa").length)} sub="atualizadas hoje" />
            <Kpi label="Candidatos" value={String(totalApps)} sub={`${inFunnel} no funil`} />
            <Kpi label="Contratados" value={String(hired)} sub="últimos 90 dias" accent />
            <Kpi label="Conversão" value={`${conversionRate}%`} sub="aplicado → contratado" />
          </div>
        </div>
      </section>

      {/* Job pipelines */}
      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="eyebrow mb-3">suas vagas</div>
          <h2 className="font-display text-4xl tracking-tight mb-8">Pipelines em andamento</h2>
          <div className="space-y-4">
            {myJobs.map((j, idx) => {
              const apps = myApps.filter((a) => a.jobId === j.id);
              return (
                <motion.div
                  key={j.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.05 }}
                >
                  <Link
                    to="/dashboard/company/jobs/$jobId" params={{ jobId: j.id }}
                    className="group block rounded-3xl glass-card border-iris p-6 hover-lift"
                  >
                    <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <h3 className="text-xl font-medium truncate">{j.title}</h3>
                          <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-success">● {j.status}</span>
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">{j.location} · {j.type} · {j.applicants} aplicantes · {j.views} visualizações</div>
                      </div>
                      <FunnelMini apps={apps} />
                      <svg viewBox="0 0 24 24" className="h-5 w-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" strokeWidth={2}><path d="M9 18l6-6-6-6" /></svg>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          {/* Talent pool teaser */}
          <div className="mt-16 grid lg:grid-cols-2 gap-6">
            <div className="rounded-3xl glass-card border-iris p-8">
              <div className="eyebrow mb-3">pool de talentos</div>
              <h3 className="font-display text-3xl tracking-tight">Acesso a {candidates.length} talentos verificados</h3>
              <p className="mt-3 text-foreground/80 text-sm">Convide diretamente para suas vagas ou inicie conversas privadas.</p>
              <Link to="/candidates" className="mt-6 inline-flex items-center gap-2 text-sm text-primary-glow hover:text-foreground">Explorar pool →</Link>
            </div>
            <div className="rounded-3xl glass-card border-iris p-8">
              <div className="eyebrow mb-3">qualidade</div>
              <h3 className="font-display text-3xl tracking-tight">Score de qualidade da empresa: <span className="text-gradient-iris italic">94/100</span></h3>
              <p className="mt-3 text-foreground/80 text-sm">Tempo de resposta &lt; 48h, descrições completas, salário transparente.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Kpi({ label, value, sub, accent }: { label: string; value: string; sub: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl glass-card border border-white/5 p-5 hover-lift">
      <div className="eyebrow">{label}</div>
      <div className={`mt-2 font-numeric text-4xl ${accent ? "text-gradient-iris" : ""}`}>{value}</div>
      <div className="mt-1 text-[11px] text-muted-foreground font-mono">{sub}</div>
    </div>
  );
}

function FunnelMini({ apps }: { apps: { stage: PipelineStage }[] }) {
  const counts = STAGES.map((s) => ({ ...s, n: apps.filter((a) => a.stage === s.id).length }));
  const max = Math.max(1, ...counts.map((c) => c.n));
  return (
    <div className="flex items-end gap-1 h-12">
      {counts.map((c) => (
        <div key={c.id} className="flex flex-col items-center gap-1 w-7" title={`${c.label}: ${c.n}`}>
          <div className="w-full rounded-t bg-white/10 overflow-hidden flex items-end" style={{ height: 38 }}>
            <div className="w-full" style={{ height: `${(c.n / max) * 100}%`, background: c.tint, boxShadow: `0 0 12px ${c.tint}` }} />
          </div>
          <div className="text-[9px] font-mono text-muted-foreground">{c.n}</div>
        </div>
      ))}
    </div>
  );
}
