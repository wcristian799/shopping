import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { Avatar } from "@/components/brand-mark";
import { applications, candidates, getJob, STAGES } from "@/lib/mock-data";

export const Route = createFileRoute("/dashboard/candidate")({
  head: () => ({ meta: [{ title: "Painel do candidato — bluestack" }] }),
  component: CandidateDashboard,
});

function CandidateDashboard() {
  const me = candidates[0];
  const myApps = applications.filter((a) => a.candidateId === me.id);
  const completion = 86;

  return (
    <div className="relative">
      <AmbientBg />

      <section className="relative pt-16 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-7">
              <div className="eyebrow mb-2">painel · candidato</div>
              <h1 className="font-display text-5xl lg:text-6xl tracking-tight">Bem-vinda, <span className="italic text-gradient-iris">{me.name.split(" ")[0]}</span></h1>
              <p className="mt-3 text-muted-foreground">Acompanhe candidaturas, ofertas e o estado do seu perfil.</p>
            </div>
            <div className="lg:col-span-5 rounded-3xl glass-card border-iris p-5">
              <div className="flex items-start gap-4">
                <Avatar initials={me.initials} accent={me.accent} size="lg" />
                <div className="flex-1">
                  <div className="text-base font-medium">{me.name}</div>
                  <div className="text-xs text-muted-foreground">{me.title}</div>
                  <div className="mt-3 flex items-center justify-between text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
                    <span>perfil</span><span className="text-primary-glow">{completion}%</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${completion}%` }} transition={{ duration: 1 }} className="h-full bg-gradient-iris" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Kpi label="Candidaturas ativas" value={String(myApps.length)} sub="em diferentes estágios" />
            <Kpi label="Visualizações no perfil" value="284" sub="últimos 30 dias" />
            <Kpi label="Mensagens" value="6" sub="2 não lidas" accent />
            <Kpi label="Match médio" value="84%" sub="suas vagas salvas" />
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <div className="eyebrow mb-2">candidaturas</div>
              <h2 className="font-display text-4xl tracking-tight">Suas vagas em andamento</h2>
            </div>
            <Link to="/jobs" className="text-sm text-primary-glow hover:text-foreground">Buscar mais vagas →</Link>
          </div>

          <div className="space-y-3">
            {myApps.map((a, i) => {
              const j = getJob(a.jobId)!;
              const stage = STAGES.find((s) => s.id === a.stage)!;
              const stageIdx = STAGES.findIndex((s) => s.id === a.stage);
              return (
                <motion.div key={a.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: i * 0.05 }}>
                  <Link to="/jobs/$jobId" params={{ jobId: j.id }} className="block rounded-2xl glass-card border-iris p-5 hover-lift">
                    <div className="flex flex-col lg:flex-row gap-4 lg:items-center">
                      <div className="flex-1 min-w-0">
                        <div className="text-base font-medium truncate">{j.title}</div>
                        <div className="text-xs text-muted-foreground">{j.company} · aplicada {a.appliedAt}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        {STAGES.slice(0, 6).map((s, k) => (
                          <span key={s.id} className="h-1.5 w-8 rounded-full" style={{ background: k <= stageIdx ? stage.tint : "rgba(255,255,255,0.06)" }} />
                        ))}
                      </div>
                      <div className="text-[11px] font-mono uppercase tracking-[0.18em] min-w-[120px] text-right" style={{ color: stage.tint }}>{stage.label}</div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

function Kpi({ label, value, sub, accent }: { label: string; value: string; sub: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl glass-card border border-white/5 p-5 hover-lift">
      <div className="eyebrow">{label}</div>
      <div className={`mt-2 font-numeric text-4xl ${accent ? "text-gradient-iris" : ""}`}>{value}</div>
      <div className="mt-1 text-[11px] text-muted-foreground font-mono">{sub}</div>
    </div>
  );
}
