/**
 * Cinematic cover header for job pages.
 * 20 deterministic CSS-only background variants — no images.
 * Picks variant from a stable hash of the job id.
 */
import { Link } from "@tanstack/react-router";
import { BrandMark } from "@/components/brand-mark";
import type { Job } from "@/lib/mock-data";
import coverBg from "@/assets/job-cover-bg.jpg";
import { TechParticles } from "@/components/tech-particles";

type CoverVariant = {
  base: string;
  layers: React.CSSProperties[];
  accent: string; // oklch chip color
  grain?: boolean;
};

const V = (
  base: string,
  layers: React.CSSProperties[],
  accent = "oklch(0.7 0.22 260)",
  grain = true,
): CoverVariant => ({ base, layers, accent, grain });

// 20 unique cinematic backdrops, expressed as layered gradients.
const VARIANTS: CoverVariant[] = [
  // 1 — deep iris aurora
  V(
    "linear-gradient(135deg, oklch(0.18 0.08 270), oklch(0.12 0.05 250))",
    [
      { background: "radial-gradient(60% 80% at 20% 30%, oklch(0.65 0.25 265 / 0.55), transparent 60%)" },
      { background: "radial-gradient(50% 70% at 85% 70%, oklch(0.7 0.22 220 / 0.45), transparent 65%)" },
    ],
    "oklch(0.78 0.2 260)",
  ),
  // 2 — magenta sunrise
  V(
    "linear-gradient(160deg, oklch(0.2 0.12 340), oklch(0.14 0.08 300))",
    [
      { background: "radial-gradient(70% 60% at 70% 20%, oklch(0.72 0.26 350 / 0.6), transparent 60%)" },
      { background: "radial-gradient(60% 70% at 10% 90%, oklch(0.55 0.22 290 / 0.5), transparent 70%)" },
    ],
    "oklch(0.78 0.22 340)",
  ),
  // 3 — emerald nightfall
  V(
    "linear-gradient(140deg, oklch(0.16 0.06 180), oklch(0.12 0.04 220))",
    [
      { background: "radial-gradient(60% 70% at 30% 60%, oklch(0.62 0.18 170 / 0.55), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 80% 25%, oklch(0.7 0.16 200 / 0.45), transparent 70%)" },
    ],
    "oklch(0.75 0.18 175)",
  ),
  // 4 — amber dusk
  V(
    "linear-gradient(150deg, oklch(0.18 0.1 60), oklch(0.12 0.06 30))",
    [
      { background: "radial-gradient(60% 70% at 75% 30%, oklch(0.78 0.2 65 / 0.55), transparent 65%)" },
      { background: "radial-gradient(70% 60% at 20% 80%, oklch(0.5 0.18 25 / 0.5), transparent 70%)" },
    ],
    "oklch(0.82 0.18 70)",
  ),
  // 5 — ice violet conic
  V(
    "conic-gradient(from 220deg at 60% 40%, oklch(0.2 0.08 260), oklch(0.14 0.05 220), oklch(0.18 0.09 280), oklch(0.2 0.08 260))",
    [{ background: "radial-gradient(40% 60% at 30% 70%, oklch(0.7 0.22 240 / 0.45), transparent 70%)" }],
    "oklch(0.78 0.2 250)",
  ),
  // 6 — crimson cinema
  V(
    "linear-gradient(135deg, oklch(0.16 0.1 20), oklch(0.1 0.06 0))",
    [
      { background: "radial-gradient(50% 60% at 80% 20%, oklch(0.6 0.24 25 / 0.55), transparent 65%)" },
      { background: "radial-gradient(60% 70% at 10% 90%, oklch(0.4 0.18 350 / 0.5), transparent 70%)" },
    ],
    "oklch(0.72 0.22 25)",
  ),
  // 7 — teal grid
  V(
    "linear-gradient(180deg, oklch(0.14 0.05 200), oklch(0.1 0.04 220))",
    [
      { background: "linear-gradient(transparent 95%, oklch(0.6 0.15 200 / 0.18) 95%), linear-gradient(90deg, transparent 95%, oklch(0.6 0.15 200 / 0.18) 95%)", backgroundSize: "44px 44px" },
      { background: "radial-gradient(50% 70% at 50% 0%, oklch(0.65 0.18 195 / 0.45), transparent 70%)" },
    ],
    "oklch(0.78 0.16 195)",
  ),
  // 8 — purple haze
  V(
    "linear-gradient(140deg, oklch(0.18 0.1 305), oklch(0.12 0.07 285))",
    [
      { background: "radial-gradient(60% 70% at 25% 25%, oklch(0.7 0.24 305 / 0.55), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 80% 80%, oklch(0.55 0.22 270 / 0.45), transparent 70%)" },
    ],
    "oklch(0.78 0.22 300)",
  ),
  // 9 — cyan blueprint
  V(
    "linear-gradient(160deg, oklch(0.14 0.06 230), oklch(0.1 0.04 245))",
    [
      { background: "linear-gradient(transparent 97%, oklch(0.7 0.18 220 / 0.25) 97%), linear-gradient(90deg, transparent 97%, oklch(0.7 0.18 220 / 0.25) 97%)", backgroundSize: "28px 28px" },
      { background: "radial-gradient(60% 70% at 80% 30%, oklch(0.7 0.2 220 / 0.4), transparent 70%)" },
    ],
    "oklch(0.78 0.2 220)",
  ),
  // 10 — golden horizon
  V(
    "linear-gradient(180deg, oklch(0.18 0.08 80), oklch(0.1 0.04 50))",
    [
      { background: "radial-gradient(120% 50% at 50% 100%, oklch(0.7 0.18 75 / 0.5), transparent 70%)" },
      { background: "radial-gradient(40% 50% at 50% 35%, oklch(0.85 0.18 90 / 0.35), transparent 70%)" },
    ],
    "oklch(0.85 0.18 85)",
  ),
  // 11 — pink midnight
  V(
    "linear-gradient(135deg, oklch(0.16 0.1 350), oklch(0.12 0.07 320))",
    [
      { background: "radial-gradient(60% 70% at 70% 30%, oklch(0.75 0.22 350 / 0.55), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 20% 80%, oklch(0.55 0.2 320 / 0.5), transparent 70%)" },
    ],
    "oklch(0.8 0.2 345)",
  ),
  // 12 — abyss blue
  V(
    "linear-gradient(180deg, oklch(0.12 0.05 250), oklch(0.08 0.03 240))",
    [
      { background: "radial-gradient(70% 60% at 50% 0%, oklch(0.6 0.22 255 / 0.55), transparent 65%)" },
      { background: "radial-gradient(40% 60% at 80% 100%, oklch(0.5 0.2 230 / 0.4), transparent 70%)" },
    ],
    "oklch(0.75 0.2 250)",
  ),
  // 13 — lime electric
  V(
    "linear-gradient(160deg, oklch(0.14 0.06 140), oklch(0.1 0.04 160))",
    [
      { background: "radial-gradient(60% 70% at 30% 30%, oklch(0.78 0.22 140 / 0.5), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 85% 70%, oklch(0.55 0.18 170 / 0.45), transparent 70%)" },
    ],
    "oklch(0.85 0.2 140)",
  ),
  // 14 — slate noir
  V(
    "linear-gradient(135deg, oklch(0.14 0.02 270), oklch(0.08 0.01 260))",
    [
      { background: "radial-gradient(60% 70% at 70% 25%, oklch(0.5 0.12 260 / 0.4), transparent 70%)" },
      { background: "linear-gradient(transparent 99%, oklch(0.7 0.05 260 / 0.18) 99%), linear-gradient(90deg, transparent 99%, oklch(0.7 0.05 260 / 0.18) 99%)", backgroundSize: "60px 60px" },
    ],
    "oklch(0.7 0.1 260)",
  ),
  // 15 — sunset peach
  V(
    "linear-gradient(180deg, oklch(0.2 0.1 40), oklch(0.14 0.07 10))",
    [
      { background: "radial-gradient(120% 50% at 50% 100%, oklch(0.75 0.2 30 / 0.55), transparent 70%)" },
      { background: "radial-gradient(50% 50% at 50% 30%, oklch(0.85 0.16 50 / 0.35), transparent 70%)" },
    ],
    "oklch(0.85 0.18 40)",
  ),
  // 16 — radial spotlight
  V(
    "radial-gradient(120% 80% at 50% 0%, oklch(0.25 0.12 270), oklch(0.08 0.04 250) 70%)",
    [{ background: "radial-gradient(40% 60% at 50% 30%, oklch(0.8 0.22 260 / 0.4), transparent 70%)" }],
    "oklch(0.78 0.22 265)",
  ),
  // 17 — cosmic dust
  V(
    "linear-gradient(135deg, oklch(0.12 0.05 280), oklch(0.1 0.04 240))",
    [
      { background: "radial-gradient(40% 60% at 20% 40%, oklch(0.7 0.22 290 / 0.4), transparent 70%)" },
      { background: "radial-gradient(40% 60% at 75% 65%, oklch(0.7 0.22 220 / 0.4), transparent 70%)" },
      { background: "radial-gradient(20% 30% at 60% 30%, oklch(0.85 0.15 320 / 0.35), transparent 75%)" },
    ],
    "oklch(0.78 0.22 280)",
  ),
  // 18 — mint glass
  V(
    "linear-gradient(160deg, oklch(0.18 0.06 165), oklch(0.12 0.04 195))",
    [
      { background: "radial-gradient(60% 70% at 80% 20%, oklch(0.78 0.18 165 / 0.5), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 15% 85%, oklch(0.6 0.18 200 / 0.4), transparent 70%)" },
    ],
    "oklch(0.82 0.18 165)",
  ),
  // 19 — diagonal stripes
  V(
    "linear-gradient(135deg, oklch(0.16 0.08 250), oklch(0.1 0.05 270))",
    [
      { background: "repeating-linear-gradient(135deg, transparent 0 28px, oklch(0.7 0.18 250 / 0.06) 28px 30px)" },
      { background: "radial-gradient(50% 70% at 70% 30%, oklch(0.7 0.2 240 / 0.45), transparent 70%)" },
    ],
    "oklch(0.78 0.2 250)",
  ),
  // 20 — rose gold
  V(
    "linear-gradient(135deg, oklch(0.18 0.08 25), oklch(0.12 0.06 350))",
    [
      { background: "radial-gradient(60% 70% at 25% 30%, oklch(0.78 0.18 25 / 0.5), transparent 65%)" },
      { background: "radial-gradient(50% 60% at 85% 70%, oklch(0.65 0.2 350 / 0.45), transparent 70%)" },
    ],
    "oklch(0.85 0.16 30)",
  ),
];

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

export function JobCover({ job, company }: { job: Job; company?: { initials: string; accent?: string; verified?: boolean } }) {
  const v = VARIANTS[hash(job.id) % VARIANTS.length];

  return (
    <section className="relative">
      <div className="relative h-[420px] md:h-[460px] w-full overflow-hidden">
        {/* base */}
        <div className="absolute inset-0" style={{ background: v.base }} />
        {/* image — blended with color base */}
        <div
          className="absolute inset-0 opacity-60 mix-blend-overlay"
          style={{ backgroundImage: `url(${coverBg})`, backgroundSize: "cover", backgroundPosition: "center" }}
        />
        <div
          className="absolute inset-0 opacity-30 mix-blend-screen"
          style={{ backgroundImage: `url(${coverBg})`, backgroundSize: "cover", backgroundPosition: "center" }}
        />
        {/* layered effects */}
        {v.layers.map((s, i) => (
          <div key={i} className="absolute inset-0 mix-blend-screen" style={s} />
        ))}
        {/* subtle moving aurora */}
        <div
          className="absolute -inset-20 opacity-50"
          style={{
            background: `radial-gradient(40% 40% at 30% 50%, ${v.accent} / 0.0, transparent 60%)`,
          }}
        />
        {/* fine grid */}
        <div
          className="absolute inset-0 opacity-[0.18] mix-blend-overlay"
          style={{
            backgroundImage:
              "linear-gradient(transparent 97%, oklch(1 0 0 / 0.5) 97%), linear-gradient(90deg, transparent 97%, oklch(1 0 0 / 0.5) 97%)",
            backgroundSize: "48px 48px",
          }}
        />
        {/* tech particles network */}
        <div className="absolute inset-0 opacity-80 mix-blend-screen">
          <TechParticles color={v.accent.replace(")", " / 0.85)")} />
        </div>
        {/* grain */}
        {v.grain && <div className="noise absolute inset-0 opacity-[0.5]" />}
        {/* bottom fade into page */}
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-background" />
        {/* soft vignette */}
        <div
          className="absolute inset-0"
          style={{ background: "radial-gradient(120% 80% at 50% 0%, transparent 50%, oklch(0 0 0 / 0.5) 100%)" }}
        />

        {/* content */}
        <div className="relative h-full mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col justify-end pb-20 md:pb-24">
          <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.18em] text-white/70">
            <Link to="/jobs" className="hover:text-white transition-colors">vagas</Link>
            <span>/</span>
            <span style={{ color: v.accent }}>{job.area}</span>
          </div>

          <h1 className="mt-2 font-display text-4xl md:text-6xl lg:text-7xl leading-[0.95] tracking-tight text-white drop-shadow-[0_4px_30px_rgba(0,0,0,0.5)] max-w-4xl">
            {job.title}
          </h1>

          <div className="mt-5 flex flex-wrap items-center gap-2.5">
            {company && (
              <Link
                to="/companies/$companyId"
                params={{ companyId: job.companyId }}
                className="group flex items-center gap-2.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 pr-4 py-1 hover:bg-white/15 transition-colors"
              >
                <BrandMark initials={company.initials} accent={company.accent} size="sm" />
                <span className="text-sm text-white">{job.company}</span>
                {company.verified && <span className="text-[10px] text-white/80 font-mono">✓ verificada</span>}
              </Link>
            )}
            <Chip>{job.location}</Chip>
            <Chip>{job.type}</Chip>
            <Chip>{job.level}</Chip>
          </div>
        </div>
      </div>
    </section>
  );
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[12px] px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-white/90">
      {children}
    </span>
  );
}
