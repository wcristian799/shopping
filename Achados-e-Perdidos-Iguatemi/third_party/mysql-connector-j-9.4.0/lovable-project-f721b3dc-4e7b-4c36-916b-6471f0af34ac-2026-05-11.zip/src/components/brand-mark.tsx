import { cn } from "@/lib/utils";

type Size = "xs" | "sm" | "md" | "lg" | "xl" | "2xl";

const sizes: Record<Size, string> = {
  xs: "h-7 w-7 text-[10px]",
  sm: "h-9 w-9 text-xs",
  md: "h-11 w-11 text-sm",
  lg: "h-14 w-14 text-base",
  xl: "h-20 w-20 text-xl",
  "2xl": "h-28 w-28 text-3xl",
};

/**
 * Geometric brand mark — a soft gradient tile with company initials.
 * Replaces emoji logos. Accepts any oklch color string for accent.
 */
export function BrandMark({
  initials,
  accent = "oklch(0.55 0.22 258)",
  size = "md",
  className,
  square = false,
}: {
  initials: string;
  accent?: string;
  size?: Size;
  className?: string;
  square?: boolean;
}) {
  const style = {
    background: `linear-gradient(135deg, ${accent}, color-mix(in oklch, ${accent} 55%, white))`,
    boxShadow: `inset 0 1px 0 oklch(1 0 0 / 0.35), 0 6px 18px -6px ${accent}`,
  } as React.CSSProperties;

  return (
    <div
      style={style}
      className={cn(
        "relative flex shrink-0 items-center justify-center font-semibold tracking-tight text-white select-none",
        square ? "rounded-xl" : "rounded-2xl",
        sizes[size],
        className,
      )}
    >
      <span className="relative z-10">{initials}</span>
      <svg
        aria-hidden
        className="absolute inset-0 h-full w-full opacity-20 mix-blend-overlay"
        viewBox="0 0 60 60"
        preserveAspectRatio="none"
      >
        <defs>
          <pattern id={`bm-${initials}`} width="8" height="8" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="0.6" fill="white" />
          </pattern>
        </defs>
        <rect width="60" height="60" fill={`url(#bm-${initials})`} />
      </svg>
    </div>
  );
}

export function Avatar({
  initials,
  accent = "oklch(0.55 0.22 258)",
  size = "md",
  className,
}: {
  initials: string;
  accent?: string;
  size?: Size;
  className?: string;
}) {
  const style = {
    background: `linear-gradient(135deg, ${accent}, color-mix(in oklch, ${accent} 60%, white))`,
  } as React.CSSProperties;
  return (
    <div
      style={style}
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full font-semibold text-white select-none ring-2 ring-white",
        sizes[size],
        className,
      )}
    >
      {initials}
    </div>
  );
}
