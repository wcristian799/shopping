import { Link, useRouterState } from "@tanstack/react-router";
import byteLogo from "@/assets/byte-logo.svg";

const nav = [
  { to: "/jobs", label: "Vagas" },
  { to: "/companies", label: "Empresas" },
  { to: "/candidates", label: "Talentos" },
  { to: "/dashboard/candidate", label: "Painel" },
];

function Logo() {
  return (
    <Link to="/" className="group flex items-center gap-2.5">
      <div className="relative">
        <div className="absolute inset-0 rounded-xl bg-primary blur-2xl opacity-40 group-hover:opacity-80 transition-opacity" />
        <img
          src={byteLogo}
          alt="byte"
          className="relative h-9 w-auto drop-shadow-[0_0_18px_oklch(0.78_0.2_240/0.45)] transition-transform group-hover:scale-105"
        />
      </div>
      <div className="leading-none hidden sm:block">
        <div className="text-[9px] font-mono uppercase tracking-[0.28em] text-muted-foreground">talent · platform</div>
      </div>
    </Link>
  );
}

export function SiteHeader() {
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-50 glass">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-4 sm:px-6 lg:px-8">
        <Logo />

        <nav className="hidden lg:flex items-center gap-0.5 rounded-full glass-card p-1">
          {nav.map((n) => {
            const active = path === n.to || (n.to !== "/" && path.startsWith(n.to));
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`px-4 py-1.5 rounded-full text-[13px] font-medium transition-all ${
                  active
                    ? "bg-gradient-iris text-white shadow-glow-soft"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                }`}
              >
                {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <Link to="/signup/candidate" className="hidden sm:inline-flex h-9 items-center px-3 text-[13px] font-medium text-muted-foreground hover:text-foreground transition-colors">
            Entrar
          </Link>
          <Link
            to="/signup/company"
            className="inline-flex h-9 items-center rounded-full bg-foreground px-4 text-[13px] font-medium text-background hover:bg-foreground/90 transition-colors shadow-soft"
          >
            Sou empresa
          </Link>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="relative mt-32 border-t border-white/5">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-12 gap-10">
          <div className="md:col-span-4">
            <Logo />
            <p className="mt-5 text-sm text-muted-foreground max-w-xs leading-relaxed">
              A plataforma de talentos tech do Brasil — construída por engenheiros, para engenheiros que querem fazer o melhor trabalho de suas vidas.
            </p>
            <div className="mt-6 flex items-center gap-2 text-[10px] font-mono uppercase tracking-[0.22em] text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
              42.180 talentos online agora
            </div>
          </div>
          <FooterCol title="Plataforma" links={[["Vagas", "/jobs"], ["Empresas", "/companies"], ["Talentos", "/candidates"]]} />
          <FooterCol title="Para você" links={[["Cadastro candidato", "/signup/candidate"], ["Painel candidato", "/dashboard/candidate"]]} />
          <FooterCol title="Para empresas" links={[["Cadastro empresa", "/signup/company"], ["Publicar vaga", "/post-job"], ["Painel empresa", "/dashboard/company"]]} />
        </div>
        <div className="mt-14 pt-8 border-t border-white/5 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between text-[11px] text-muted-foreground">
          <p className="font-mono">© 2026 bluestack — todos os direitos reservados.</p>
          <p className="font-mono uppercase tracking-[0.24em]">crafted in Brazil</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div className="md:col-span-2">
      <h4 className="text-[10px] font-mono font-medium uppercase tracking-[0.22em] text-primary-glow mb-4">{title}</h4>
      <ul className="space-y-2.5 text-sm">
        {links.map(([label, to]) => (
          <li key={to}>
            <Link to={to} className="text-foreground/75 hover:text-foreground transition-colors">{label}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
