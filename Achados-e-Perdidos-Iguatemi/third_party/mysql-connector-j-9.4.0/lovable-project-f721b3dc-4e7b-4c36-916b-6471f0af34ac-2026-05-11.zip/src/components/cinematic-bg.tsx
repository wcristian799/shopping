/**
 * Animated cinematic backdrop — aurora orbs + grid + noise.
 * Uses CSS animations only (GPU-friendly, no JS).
 */
export function CinematicBg({ intensity = 1 }: { intensity?: number }) {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-60" />
      <div
        className="aurora-orb"
        style={{
          top: "-10%", left: "-8%",
          width: `${600 * intensity}px`, height: `${600 * intensity}px`,
          background: "radial-gradient(circle, oklch(0.55 0.28 262 / 0.6), transparent 65%)",
          animationDelay: "0s",
        }}
      />
      <div
        className="aurora-orb"
        style={{
          top: "12%", right: "-12%",
          width: `${520 * intensity}px`, height: `${520 * intensity}px`,
          background: "radial-gradient(circle, oklch(0.7 0.22 230 / 0.5), transparent 65%)",
          animationDelay: "-6s",
        }}
      />
      <div
        className="aurora-orb"
        style={{
          bottom: "-15%", left: "30%",
          width: `${720 * intensity}px`, height: `${720 * intensity}px`,
          background: "radial-gradient(circle, oklch(0.4 0.24 285 / 0.5), transparent 65%)",
          animationDelay: "-12s",
        }}
      />
      <div className="noise absolute inset-0" />
    </div>
  );
}

/** Subtle ambient version (for inner pages, not home). */
export function AmbientBg() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 grid-pattern-fine opacity-40" />
      <div
        className="aurora-orb"
        style={{
          top: "-20%", left: "60%",
          width: "700px", height: "700px",
          background: "radial-gradient(circle, oklch(0.55 0.28 262 / 0.35), transparent 65%)",
        }}
      />
      <div
        className="aurora-orb"
        style={{
          top: "40%", left: "-20%",
          width: "600px", height: "600px",
          background: "radial-gradient(circle, oklch(0.7 0.22 230 / 0.22), transparent 65%)",
          animationDelay: "-10s",
        }}
      />
    </div>
  );
}

/** Floating particles — pure CSS, deterministic positions, dynamic drift. */
export function Particles({ count = 18 }: { count?: number }) {
  const seeds = Array.from({ length: count }, (_, i) => i);
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {seeds.map((i) => {
        const x = (i * 37) % 100;
        const y = (i * 53) % 100;
        const size = 2 + (i % 5);
        const delay = (i * 0.37) % 8;
        const dur = 7 + (i % 9);
        const dx = ((i * 17) % 200) - 100; // -100 to 100 px
        const dy = ((i * 29) % 240) - 120;
        const rot = ((i * 13) % 60) - 30;
        return (
          <span
            key={i}
            className="absolute rounded-full bg-primary-glow/80"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              width: `${size}px`,
              height: `${size}px`,
              ["--dx" as string]: `${dx}px`,
              ["--dy" as string]: `${dy}px`,
              ["--rot" as string]: `${rot}deg`,
              animation: `drift ${dur}s ease-in-out ${delay}s infinite alternate, pulse-slow ${3 + (i % 4)}s ease-in-out ${delay}s infinite`,
              boxShadow: "0 0 14px oklch(0.78 0.2 240 / 0.9)",
            }}
          />
        );
      })}
    </div>
  );
}
