import { Link } from "@tanstack/react-router";
import { BrandMark } from "@/components/brand-mark";
import type { Job } from "@/lib/mock-data";

export function JobCard({ job, index = 0 }: { job: Job; index?: number }) {
  const tilt = index % 4 === 1 ? "tilt-r" : index % 4 === 3 ? "tilt-l" : "";
  const company = { initials: job.company.split(" ").map((p) => p[0]).slice(0,2).join(""), accent: "oklch(0.62 0.24 258)" };

  return (
    <Link
      to="/jobs/$jobId"
      params={{ jobId: job.id }}
      className={`group relative block rounded-3xl glass-card border-iris hover-lift overflow-hidden ${tilt}`}
    >
      {/* Glow on hover */}
      <div
        className="pointer-events-none absolute -inset-1 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-2xl"
        style={{ background: "radial-gradient(closest-side, oklch(0.62 0.24 258 / 0.4), transparent)" }}
      />

      <div className="relative p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4 min-w-0">
            <BrandMark initials={company.initials} accent={company.accent} size="md" square />
            <div className="min-w-0">
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-primary-glow">{job.area}</div>
              <h3 className="mt-1.5 text-[17px] font-medium leading-tight text-foreground line-clamp-2 group-hover:text-gradient-iris transition-all">
                {job.title}
              </h3>
              <div className="mt-1 text-[13px] text-muted-foreground">{job.company}</div>
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">salário</div>
            <div className="mt-1 text-[13px] font-semibold text-foreground">{job.salary}</div>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-1.5">
          {job.tags.slice(0, 4).map((t) => (
            <span key={t} className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-white/5 border border-white/5 text-foreground/80">
              {t}
            </span>
          ))}
          {job.tags.length > 4 && (
            <span className="text-[11px] font-mono px-2 py-0.5 rounded-md text-muted-foreground">+{job.tags.length - 4}</span>
          )}
        </div>

        <div className="mt-5 flex items-center justify-between text-[11px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <Pill>{job.type}</Pill>
            <Pill>{job.level}</Pill>
            <Pill>{job.location.split(",")[0]}</Pill>
          </div>
          <span className="font-mono">{job.postedAt}</span>
        </div>
      </div>
    </Link>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 text-foreground/80 border border-white/5">
      {children}
    </span>
  );
}
