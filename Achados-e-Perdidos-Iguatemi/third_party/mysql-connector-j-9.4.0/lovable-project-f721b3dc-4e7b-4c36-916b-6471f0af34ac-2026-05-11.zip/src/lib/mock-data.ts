export type Job = {
  id: string;
  title: string;
  company: string;
  companyId: string;
  location: string;
  type: "Remoto" | "Híbrido" | "Presencial";
  level: "Estágio" | "Júnior" | "Pleno" | "Sênior" | "Lead/Staff";
  area: "Engenharia" | "Design" | "Produto" | "Dados" | "DevOps" | "Mobile";
  salary: string;
  salaryMin: number;
  salaryMax: number;
  tags: string[];
  postedAt: string;
  applicants: number;
  views: number;
  description: string;
  responsibilities: string[];
  requirements: string[];
  benefits: string[];
  status: "Ativa" | "Pausada" | "Encerrada";
};

export type Company = {
  id: string;
  name: string;
  initials: string;
  accent: string; // oklch color string
  industry: string;
  size: string;
  founded: number;
  location: string;
  about: string;
  mission: string;
  culture: string;
  website: string;
  openJobs: number;
  rating: number;
  followers: number;
  verified: boolean;
};

export type Candidate = {
  id: string;
  name: string;
  title: string;
  initials: string;
  accent: string;
  location: string;
  experience: string;
  yearsOfExperience: number;
  level: "Júnior" | "Pleno" | "Sênior" | "Lead/Staff";
  skills: string[];
  bio: string;
  available: boolean;
  expectedSalary: string;
  workMode: "Remoto" | "Híbrido" | "Presencial" | "Indiferente";
  email: string;
  linkedin: string;
  github: string;
};

export type PipelineStage =
  | "applied"
  | "screening"
  | "interview"
  | "tech_test"
  | "offer"
  | "hired"
  | "rejected";

export const STAGES: { id: PipelineStage; label: string; tint: string }[] = [
  { id: "applied",   label: "Candidatado",     tint: "oklch(0.7 0.05 258)" },
  { id: "screening", label: "Triagem",         tint: "oklch(0.7 0.13 230)" },
  { id: "interview", label: "Entrevista",      tint: "oklch(0.65 0.18 280)" },
  { id: "tech_test", label: "Teste técnico",   tint: "oklch(0.7 0.16 200)" },
  { id: "offer",     label: "Proposta",        tint: "oklch(0.78 0.16 75)" },
  { id: "hired",     label: "Contratado",      tint: "oklch(0.66 0.16 155)" },
  { id: "rejected",  label: "Não selecionado", tint: "oklch(0.6 0.04 25)" },
];

export type Application = {
  id: string;
  jobId: string;
  candidateId: string;
  stage: PipelineStage;
  appliedAt: string;
  rating: 0 | 1 | 2 | 3 | 4 | 5;
  fit: number; // 0-100
  note?: string;
};

const accents = [
  "oklch(0.55 0.22 258)",
  "oklch(0.6 0.2 165)",
  "oklch(0.65 0.22 35)",
  "oklch(0.62 0.24 305)",
  "oklch(0.55 0.18 195)",
  "oklch(0.7 0.18 80)",
  "oklch(0.55 0.22 0)",
  "oklch(0.55 0.18 145)",
];

export const companies: Company[] = [
  { id: "c1", name: "Nebula Tech", initials: "NT", accent: accents[0], industry: "SaaS B2B", size: "200-500", founded: 2017, location: "São Paulo, SP", about: "Construímos a próxima geração de ferramentas de produtividade colaborativa.", mission: "Empoderar times distribuídos a fazerem o melhor trabalho de suas vidas.", culture: "Autonomia, transparência radical e foco em resultado.", website: "nebula.tech", openJobs: 12, rating: 4.8, followers: 4820, verified: true },
  { id: "c2", name: "Quantum Labs", initials: "QL", accent: accents[3], industry: "AI / ML", size: "50-200", founded: 2020, location: "Rio de Janeiro, RJ", about: "Pesquisa de ponta em inteligência artificial aplicada à indústria.", mission: "Tornar a IA segura, interpretável e útil para todos.", culture: "Profundidade técnica e curiosidade científica.", website: "quantumlabs.io", openJobs: 8, rating: 4.9, followers: 9120, verified: true },
  { id: "c3", name: "Pulse Fintech", initials: "PF", accent: accents[1], industry: "Fintech", size: "500-1000", founded: 2015, location: "São Paulo, SP", about: "Reinventando pagamentos para a América Latina.", mission: "Acesso financeiro universal através de tecnologia.", culture: "Movimento, ownership e zero burocracia.", website: "pulse.fi", openJobs: 21, rating: 4.6, followers: 12300, verified: true },
  { id: "c4", name: "Orbit Cloud", initials: "OC", accent: accents[4], industry: "Cloud Infrastructure", size: "1000+", founded: 2012, location: "Belo Horizonte, MG", about: "Infraestrutura cloud-native escalável para empresas globais.", mission: "Tornar a infraestrutura invisível.", culture: "Engenharia de excelência, on-call rotativo, cultura SRE.", website: "orbit.cloud", openJobs: 15, rating: 4.7, followers: 7500, verified: true },
  { id: "c5", name: "Helix Bio", initials: "HB", accent: accents[5], industry: "BioTech", size: "100-200", founded: 2019, location: "Florianópolis, SC", about: "Tecnologia transformando a saúde personalizada.", mission: "Descobertas científicas em produção, mais rápido.", culture: "Multidisciplinar, dados-first, ético.", website: "helix.bio", openJobs: 6, rating: 4.5, followers: 2100, verified: true },
  { id: "c6", name: "Vortex Games", initials: "VG", accent: accents[2], industry: "Games", size: "50-100", founded: 2018, location: "Curitiba, PR", about: "Estúdio de jogos AAA independente.", mission: "Criar mundos que importam.", culture: "Criatividade sem limites, sem crunch.", website: "vortex.gg", openJobs: 9, rating: 4.7, followers: 18900, verified: true },
  { id: "c7", name: "Aurora Labs", initials: "AL", accent: accents[6], industry: "Robotics", size: "10-50", founded: 2022, location: "Campinas, SP", about: "Robôs autônomos para logística.", mission: "Automatizar o trabalho repetitivo.", culture: "Hardware + software, hands-on.", website: "auroralabs.tech", openJobs: 4, rating: 4.6, followers: 980, verified: false },
  { id: "c8", name: "Mosaic Studio", initials: "MS", accent: accents[7], industry: "Design / Product", size: "10-50", founded: 2019, location: "Remoto", about: "Estúdio de produto e design para fundadores ambiciosos.", mission: "Design como vantagem competitiva.", culture: "Craft obsessivo, processo enxuto.", website: "mosaic.studio", openJobs: 3, rating: 4.9, followers: 3400, verified: true },
];

export const jobs: Job[] = [
  { id: "j1", title: "Engenheiro(a) de Software Sênior", company: "Nebula Tech", companyId: "c1", location: "São Paulo, SP", type: "Remoto", level: "Sênior", area: "Engenharia", salary: "R$ 18k – 25k", salaryMin: 18000, salaryMax: 25000, tags: ["React", "TypeScript", "Node.js", "AWS", "PostgreSQL"], postedAt: "2 dias atrás", applicants: 47, views: 1420, status: "Ativa",
    description: "Procuramos um(a) engenheiro(a) sênior para liderar evoluções da nossa plataforma core, atendendo +200 mil usuários ativos.",
    responsibilities: ["Desenhar arquitetura de novos módulos", "Mentorar engenheiros plenos e juniores", "Definir padrões de qualidade e observabilidade", "Colaborar com Produto e Design no roadmap"],
    requirements: ["5+ anos de experiência em produto", "Domínio em React e Node.js", "Experiência sólida com AWS", "Inglês avançado para comunicação escrita"],
    benefits: ["PLR semestral", "Plano de saúde premium", "Stock options (vesting 4y)", "Home office + auxílio setup R$ 5k", "30 dias de férias"] },
  { id: "j2", title: "Engenheiro(a) de Machine Learning", company: "Quantum Labs", companyId: "c2", location: "Rio de Janeiro, RJ", type: "Híbrido", level: "Pleno", area: "Dados", salary: "R$ 14k – 19k", salaryMin: 14000, salaryMax: 19000, tags: ["Python", "PyTorch", "MLOps", "LLMs", "CUDA"], postedAt: "1 dia atrás", applicants: 89, views: 2110, status: "Ativa",
    description: "Junte-se ao time que está construindo modelos de linguagem de próxima geração para o português brasileiro.",
    responsibilities: ["Treinar e fine-tunar LLMs", "Desenhar pipelines de dados em escala", "Avaliar qualidade e bias dos modelos"],
    requirements: ["Mestrado ou PhD em áreas correlatas", "Experiência com PyTorch e distributed training", "Publicações são um plus"],
    benefits: ["Bolsa de pesquisa anual", "Conferências internacionais", "GPU dedicada A100"] },
  { id: "j3", title: "Designer de Produto Sênior", company: "Pulse Fintech", companyId: "c3", location: "São Paulo, SP", type: "Híbrido", level: "Sênior", area: "Design", salary: "R$ 14k – 20k", salaryMin: 14000, salaryMax: 20000, tags: ["Figma", "Design System", "UX Research", "Prototyping"], postedAt: "3 dias atrás", applicants: 62, views: 1890, status: "Ativa",
    description: "Lidere o design de novos produtos financeiros que impactam milhões de brasileiros.",
    responsibilities: ["Liderar discovery e definição de soluções", "Evoluir o design system Constellation", "Conduzir pesquisas qualitativas"],
    requirements: ["Portfolio sólido em produtos B2C", "Experiência com fintechs ou regulamentação", "Maestria em Figma"],
    benefits: ["Equipamento Apple à escolha", "Vale-refeição R$ 1.200", "Gympass Platinum"] },
  { id: "j4", title: "Site Reliability Engineer", company: "Orbit Cloud", companyId: "c4", location: "Remoto", type: "Remoto", level: "Sênior", area: "DevOps", salary: "R$ 16k – 22k", salaryMin: 16000, salaryMax: 22000, tags: ["Kubernetes", "Terraform", "GCP", "Go", "Observability"], postedAt: "5 dias atrás", applicants: 34, views: 990, status: "Ativa",
    description: "Escale infraestrutura para milhares de clientes globais com SLA de 99.99%.",
    responsibilities: ["Manter SLOs e error budgets", "Automatizar resposta a incidentes", "Construir tooling interno em Go"],
    requirements: ["Kubernetes em produção (3+ anos)", "IaC com Terraform", "On-call experience"],
    benefits: ["100% remoto global", "Budget de aprendizado USD 2k/ano", "4 semanas de férias + 1 semana sabbatical"] },
  { id: "j5", title: "Data Scientist", company: "Helix Bio", companyId: "c5", location: "Florianópolis, SC", type: "Presencial", level: "Pleno", area: "Dados", salary: "R$ 12k – 17k", salaryMin: 12000, salaryMax: 17000, tags: ["Python", "R", "Bioinformática", "SQL", "Spark"], postedAt: "1 semana atrás", applicants: 28, views: 720, status: "Ativa",
    description: "Use dados para acelerar descobertas científicas em saúde personalizada.",
    responsibilities: ["Modelagem estatística avançada", "Trabalhar com biólogos e médicos", "Construir dashboards de validação"],
    requirements: ["Background quantitativo", "Python e R fluentes", "Estatística avançada"],
    benefits: ["Plano de saúde", "Auxílio mudança até R$ 10k", "Programa de café gourmet"] },
  { id: "j6", title: "Game Developer Unity", company: "Vortex Games", companyId: "c6", location: "Curitiba, PR", type: "Híbrido", level: "Pleno", area: "Engenharia", salary: "R$ 10k – 14k", salaryMin: 10000, salaryMax: 14000, tags: ["Unity", "C#", "Shaders", "3D", "Multiplayer"], postedAt: "4 dias atrás", applicants: 52, views: 1340, status: "Ativa",
    description: "Desenvolva nosso próximo título AAA em parceria com publisher internacional.",
    responsibilities: ["Implementar gameplay systems", "Otimizar performance em consoles", "Trabalhar com artistas técnicos"],
    requirements: ["Unity em produção", "C# avançado", "Portfolio de jogos publicados"],
    benefits: ["Setup gamer top de linha", "Sextas livres", "Crédito Steam mensal"] },
  { id: "j7", title: "Desenvolvedor(a) Frontend Júnior", company: "Nebula Tech", companyId: "c1", location: "Remoto", type: "Remoto", level: "Júnior", area: "Engenharia", salary: "R$ 5k – 7,5k", salaryMin: 5000, salaryMax: 7500, tags: ["React", "TypeScript", "CSS", "Git"], postedAt: "1 dia atrás", applicants: 184, views: 3200, status: "Ativa",
    description: "Comece sua carreira em uma equipe de elite com mentoria estruturada.",
    responsibilities: ["Implementar features no front", "Pareamento diário com sêniores", "Code reviews e estudos de caso"],
    requirements: ["Conhecimento de React", "HTML/CSS sólidos", "Vontade de aprender"],
    benefits: ["Mentoria 1:1 semanal", "Plano de carreira mapeado", "Cursos pagos"] },
  { id: "j8", title: "Product Manager Sênior", company: "Pulse Fintech", companyId: "c3", location: "São Paulo, SP", type: "Híbrido", level: "Sênior", area: "Produto", salary: "R$ 20k – 28k", salaryMin: 20000, salaryMax: 28000, tags: ["Product", "Analytics", "Agile", "B2B"], postedAt: "6 dias atrás", applicants: 41, views: 1580, status: "Ativa",
    description: "Lidere a estratégia de produtos B2B que processam +R$ 2B/mês em transações.",
    responsibilities: ["Definir visão e roadmap", "Priorização baseada em dados", "Stakeholder management"],
    requirements: ["5+ anos como PM", "Background técnico", "Inglês fluente"],
    benefits: ["PLR generoso", "Equity", "Sabbatical de 30 dias"] },
  { id: "j9", title: "Mobile Engineer (React Native)", company: "Mosaic Studio", companyId: "c8", location: "Remoto", type: "Remoto", level: "Pleno", area: "Mobile", salary: "R$ 12k – 16k", salaryMin: 12000, salaryMax: 16000, tags: ["React Native", "TypeScript", "iOS", "Android"], postedAt: "2 dias atrás", applicants: 36, views: 880, status: "Ativa",
    description: "Construa apps premium para fundadores que pagam pelo cuidado nos detalhes.",
    responsibilities: ["Apps de ponta em RN", "Animações fluidas e UX impecável", "Publicação nas lojas"],
    requirements: ["3+ anos com React Native", "Conhecimento de nativo (Swift/Kotlin)"],
    benefits: ["Trabalho 100% remoto", "Sextas curtas", "Equipamento à escolha"] },
];

const firstNames = ["Ana", "Bruno", "Carla", "Diego", "Eduarda", "Felipe", "Gabriela", "Heitor", "Isabela", "João", "Karina", "Lucas"];
const lastNames = ["Silva", "Costa", "Mendes", "Rocha", "Lima", "Souza", "Nunes", "Alves", "Pereira", "Santos", "Almeida", "Ribeiro"];

function ini(name: string) { return name.split(" ").map((p) => p[0]).slice(0, 2).join(""); }

export const candidates: Candidate[] = [
  { id: "p1", name: "Ana Silva", title: "Desenvolvedora Full Stack Sênior", initials: "AS", accent: accents[0], location: "São Paulo, SP", experience: "8 anos", yearsOfExperience: 8, level: "Sênior", skills: ["React", "Node.js", "TypeScript", "AWS", "PostgreSQL", "Kafka"], bio: "Apaixonada por construir produtos escaláveis com foco em DX e qualidade.", available: true, expectedSalary: "R$ 22k", workMode: "Remoto", email: "ana.silva@example.com", linkedin: "ana-silva", github: "anasilva" },
  { id: "p2", name: "Bruno Costa", title: "ML Engineer", initials: "BC", accent: accents[3], location: "Rio de Janeiro, RJ", experience: "5 anos", yearsOfExperience: 5, level: "Pleno", skills: ["Python", "PyTorch", "MLOps", "Kubernetes", "Ray"], bio: "Pesquisador aplicado em deep learning e LLMs.", available: true, expectedSalary: "R$ 17k", workMode: "Híbrido", email: "bruno@example.com", linkedin: "brunocosta", github: "brunocosta" },
  { id: "p3", name: "Carla Mendes", title: "Product Designer Sênior", initials: "CM", accent: accents[1], location: "Florianópolis, SC", experience: "7 anos", yearsOfExperience: 7, level: "Sênior", skills: ["Figma", "Design Systems", "Research", "Prototyping", "Motion"], bio: "Designer com olhar estratégico para B2B SaaS.", available: false, expectedSalary: "R$ 18k", workMode: "Remoto", email: "carla@example.com", linkedin: "carlamendes", github: "" },
  { id: "p4", name: "Diego Rocha", title: "DevOps / SRE", initials: "DR", accent: accents[4], location: "Remoto", experience: "9 anos", yearsOfExperience: 9, level: "Lead/Staff", skills: ["K8s", "Terraform", "GCP", "Go", "Observability", "Istio"], bio: "Construindo plataformas confiáveis para escala global.", available: true, expectedSalary: "R$ 24k", workMode: "Remoto", email: "diego@example.com", linkedin: "diegorocha", github: "drocha" },
  { id: "p5", name: "Eduarda Lima", title: "Data Scientist", initials: "EL", accent: accents[5], location: "Belo Horizonte, MG", experience: "4 anos", yearsOfExperience: 4, level: "Pleno", skills: ["Python", "SQL", "Spark", "Tableau", "dbt"], bio: "Transformando dados em decisões de negócio.", available: true, expectedSalary: "R$ 14k", workMode: "Híbrido", email: "edu@example.com", linkedin: "edulima", github: "" },
  { id: "p6", name: "Felipe Souza", title: "Mobile Engineer", initials: "FS", accent: accents[2], location: "Curitiba, PR", experience: "5 anos", yearsOfExperience: 5, level: "Pleno", skills: ["React Native", "Swift", "Kotlin", "GraphQL"], bio: "Apps mobile com performance nativa e UX impecável.", available: true, expectedSalary: "R$ 15k", workMode: "Remoto", email: "felipe@example.com", linkedin: "felipesouza", github: "fsouza" },
  { id: "p7", name: "Gabriela Nunes", title: "Backend Engineer Pleno", initials: "GN", accent: accents[6], location: "Recife, PE", experience: "3 anos", yearsOfExperience: 3, level: "Pleno", skills: ["Java", "Spring", "Kafka", "PostgreSQL", "DDD"], bio: "Sistemas distribuídos e arquitetura limpa.", available: true, expectedSalary: "R$ 13k", workMode: "Remoto", email: "gabi@example.com", linkedin: "gabinunes", github: "gnunes" },
  { id: "p8", name: "Heitor Alves", title: "Frontend Engineer Júnior", initials: "HA", accent: accents[7], location: "Porto Alegre, RS", experience: "2 anos", yearsOfExperience: 2, level: "Júnior", skills: ["React", "Next.js", "Tailwind", "TypeScript"], bio: "Em busca da próxima oportunidade desafiadora.", available: true, expectedSalary: "R$ 7k", workMode: "Remoto", email: "heitor@example.com", linkedin: "heitor", github: "heitor" },
  { id: "p9", name: "Isabela Pereira", title: "Engineering Manager", initials: "IP", accent: accents[0], location: "São Paulo, SP", experience: "11 anos", yearsOfExperience: 11, level: "Lead/Staff", skills: ["People Management", "Architecture", "Coaching"], bio: "Construindo times de alta performance.", available: false, expectedSalary: "R$ 28k", workMode: "Híbrido", email: "isa@example.com", linkedin: "isapereira", github: "" },
  { id: "p10", name: "João Santos", title: "Security Engineer", initials: "JS", accent: accents[3], location: "Brasília, DF", experience: "6 anos", yearsOfExperience: 6, level: "Sênior", skills: ["AppSec", "Pentesting", "Cloud Security"], bio: "Segurança como produto, não como gate.", available: true, expectedSalary: "R$ 19k", workMode: "Remoto", email: "joao@example.com", linkedin: "joaosantos", github: "" },
  { id: "p11", name: "Karina Almeida", title: "QA Engineer Sênior", initials: "KA", accent: accents[1], location: "Salvador, BA", experience: "7 anos", yearsOfExperience: 7, level: "Sênior", skills: ["Cypress", "Playwright", "Test Automation", "K6"], bio: "Qualidade desde o discovery até produção.", available: true, expectedSalary: "R$ 14k", workMode: "Remoto", email: "karina@example.com", linkedin: "karina", github: "" },
  { id: "p12", name: "Lucas Ribeiro", title: "Staff Engineer", initials: "LR", accent: accents[4], location: "São Paulo, SP", experience: "12 anos", yearsOfExperience: 12, level: "Lead/Staff", skills: ["Distributed Systems", "Go", "Rust", "Architecture"], bio: "Sistemas que aguentam o real-world traffic.", available: false, expectedSalary: "R$ 32k", workMode: "Híbrido", email: "lucas@example.com", linkedin: "lucasribeiro", github: "lucasr" },
];

// Applications mapping candidates to jobs across pipeline
export const applications: Application[] = [
  { id: "a1", jobId: "j1", candidateId: "p1", stage: "interview", appliedAt: "5 dias", rating: 5, fit: 92, note: "Forte em sistemas distribuídos." },
  { id: "a2", jobId: "j1", candidateId: "p4", stage: "tech_test", appliedAt: "4 dias", rating: 4, fit: 88 },
  { id: "a3", jobId: "j1", candidateId: "p7", stage: "applied", appliedAt: "1 dia", rating: 0, fit: 71 },
  { id: "a4", jobId: "j1", candidateId: "p9", stage: "screening", appliedAt: "3 dias", rating: 4, fit: 85 },
  { id: "a5", jobId: "j1", candidateId: "p10", stage: "offer", appliedAt: "10 dias", rating: 5, fit: 95, note: "Proposta enviada na sexta." },
  { id: "a6", jobId: "j1", candidateId: "p12", stage: "hired", appliedAt: "20 dias", rating: 5, fit: 98 },
  { id: "a7", jobId: "j1", candidateId: "p8", stage: "rejected", appliedAt: "8 dias", rating: 2, fit: 45 },
  { id: "a8", jobId: "j1", candidateId: "p2", stage: "applied", appliedAt: "2 dias", rating: 0, fit: 64 },
  { id: "a9", jobId: "j1", candidateId: "p11", stage: "screening", appliedAt: "2 dias", rating: 3, fit: 76 },
  { id: "a10", jobId: "j2", candidateId: "p2", stage: "interview", appliedAt: "6 dias", rating: 5, fit: 94 },
  { id: "a11", jobId: "j2", candidateId: "p5", stage: "applied", appliedAt: "1 dia", rating: 0, fit: 70 },
  { id: "a12", jobId: "j3", candidateId: "p3", stage: "offer", appliedAt: "9 dias", rating: 5, fit: 96 },
  // Applications by p1 (current candidate POV)
  { id: "a13", jobId: "j4", candidateId: "p1", stage: "screening", appliedAt: "2 dias", rating: 4, fit: 82 },
  { id: "a14", jobId: "j8", candidateId: "p1", stage: "applied", appliedAt: "1 dia", rating: 0, fit: 68 },
];

export function getApplicationsByJob(jobId: string) {
  return applications.filter((a) => a.jobId === jobId);
}
export function getCandidate(id: string) {
  return candidates.find((c) => c.id === id);
}
export function getJob(id: string) {
  return jobs.find((j) => j.id === id);
}
export function getCompany(id: string) {
  return companies.find((c) => c.id === id);
}

export { ini, firstNames, lastNames };
