import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { Avatar } from "@/components/brand-mark";
import { candidates } from "@/lib/mock-data";

export const Route = createFileRoute("/candidates/")({
  head: () => ({
    meta: [
      { title: "Pool de talentos tech — bluestack" },
      { name: "description", content: "Encontre engenheiros, designers e PMs prontos para sua próxima contratação." },
    ],
  }),
  component: TalentsList,
});

const levels = ["Júnior", "Pleno", "Sênior", "Lead/Staff"] as const;
const modes = ["Remoto", "Híbrido", "Presencial", "Indiferente"] as const;

function TalentsList() {
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<string | null>(null);
  const [mode, setMode] = useState<string | null>(null);
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  const list = useMemo(() => {
    let l = [...candidates];
    if (q) {
      const s = q.toLowerCase();
      l = l.filter((c) => c.name.toLowerCase().includes(s) || c.title.toLowerCase().includes(s) || c.skills.some((sk) => sk.toLowerCase().includes(s)));
    }
    if (level) l = l.filter((c) => c.level === level);
    if (mode) l = l.filter((c) => c.workMode === mode);
    if (onlyAvailable) l = l.filter((c) => c.available);
    return l;
  }, [q, level, mode, onlyAvailable]);

  return (
    <div className="relative">
      <AmbientBg />
      <section className="relative pt-20 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-8">
              <div className="eyebrow mb-3">{candidates.length} talentos verificados</div>
              <h1 className="font-display text-6xl lg:text-7xl tracking-tight">
                Talentos que <span className="italic text-gradient-iris">entregam</span>.
              </h1>
            </div>
            <p className="lg:col-span-4 text-sm text-muted-foreground">
              Pool curado de profissionais com track record validado. Acesso restrito a empresas verificadas.
            </p>
          </div>

          <div className="mt-10 flex flex-col lg:flex-row gap-3">
            <div className="flex-1 flex items-center gap-3 rounded-2xl glass-strong border-iris px-5 py-3.5">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary-glow" fill="none" stroke="currentColor" strokeWidth={1.8}>
                <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
              </svg>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nome, cargo ou stack…" className="flex-1 bg-transparent outline-none text-base placeholder:text-muted-foreground" />
            </div>
            <button
              onClick={() => setOnlyAvailable((v) => !v)}
              className={`rounded-2xl px-5 py-3 text-sm font-medium transition-all ${
                onlyAvailable ? "bg-gradient-iris text-white shadow-glow" : "glass-strong border-iris text-foreground"
              }`}
            >
              {onlyAvailable ? "✓ " : ""}Disponíveis agora
            </button>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <FilterGroup label="Nível" options={[...levels]} value={level} onChange={setLevel} />
            <FilterGroup label="Modalidade" options={[...modes]} value={mode} onChange={setMode} />
          </div>
        </div>
      </section>

      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((c, i) => (
            <motion.div key={c.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: (i % 9) * 0.04 }}>
              <Link
                to="/candidates/$candidateId" params={{ candidateId: c.id }}
                className="group block relative rounded-3xl glass-card border-iris hover-lift overflow-hidden p-6"
                style={{ transform: i % 4 === 1 ? "rotate(0.6deg)" : i % 4 === 3 ? "rotate(-0.6deg)" : undefined }}
              >
                <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full opacity-30 blur-3xl group-hover:opacity-70 transition-opacity" style={{ background: c.accent }} />
                <div className="relative flex items-start gap-4">
                  <Avatar initials={c.initials} accent={c.accent} size="lg" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-medium truncate">{c.name}</h3>
                      {c.available && <span className="h-2 w-2 rounded-full bg-success animate-pulse" title="Disponível" />}
                    </div>
                    <div className="text-[12px] text-primary-glow font-mono uppercase tracking-[0.18em] mt-0.5">{c.level}</div>
                    <p className="text-sm text-foreground/80 mt-1">{c.title}</p>
                  </div>
                </div>

                <p className="mt-4 text-sm text-foreground/75 line-clamp-2">{c.bio}</p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  {c.skills.slice(0, 4).map((s) => (
                    <span key={s} className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-white/5 border border-white/5 text-foreground/85">{s}</span>
                  ))}
                  {c.skills.length > 4 && <span className="text-[11px] font-mono text-muted-foreground px-1">+{c.skills.length - 4}</span>}
                </div>

                <div className="mt-5 flex items-center justify-between text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
                  <span>{c.experience} · {c.location.split(",")[0]}</span>
                  <span className="text-foreground/85">{c.expectedSalary}</span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}

function FilterGroup({ label, options, value, onChange }: { label: string; options: string[]; value: string | null; onChange: (v: string | null) => void }) {
  return (
    <div className="flex items-center gap-1.5 rounded-full glass-card border border-white/5 p-1">
      <span className="px-3 text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      {options.map((o) => {
        const active = value === o;
        return (
          <button key={o} onClick={() => onChange(active ? null : o)} className={`px-3 py-1 rounded-full text-[12px] font-medium transition-all ${active ? "bg-gradient-iris text-white shadow-glow-soft" : "text-foreground/75 hover:text-foreground hover:bg-white/5"}`}>
            {o}
          </button>
        );
      })}
    </div>
  );
}
