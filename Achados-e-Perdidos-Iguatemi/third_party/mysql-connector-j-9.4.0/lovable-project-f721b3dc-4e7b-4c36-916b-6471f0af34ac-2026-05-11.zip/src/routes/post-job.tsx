import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { AmbientBg } from "@/components/cinematic-bg";

export const Route = createFileRoute("/post-job")({
  head: () => ({ meta: [{ title: "Publicar vaga — bluestack" }] }),
  component: PostJob,
});

function PostJob() {
  const nav = useNavigate();
  const [tags, setTags] = useState<string[]>(["React", "TypeScript"]);
  const [tagInput, setTagInput] = useState("");

  function submit() { toast.success("Vaga publicada!"); nav({ to: "/dashboard/company" }); }

  return (
    <div className="relative min-h-screen">
      <AmbientBg />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-12 gap-10">
        <aside className="lg:col-span-4">
          <div className="eyebrow mb-3">publicar vaga</div>
          <h1 className="font-display text-5xl lg:text-6xl tracking-tight">Atraia <span className="italic text-gradient-iris">o melhor</span>.</h1>
          <div className="mt-8 rounded-2xl glass-card border-iris p-5 space-y-3 text-sm">
            <div className="eyebrow">checklist de qualidade</div>
            {["Salário transparente", "Stack clara", "Responsabilidades específicas", "Cultura mencionada", "Benefícios reais"].map((c) => (
              <div key={c} className="flex items-center gap-2 text-foreground/85">
                <span className="h-4 w-4 rounded-full bg-success/20 text-success grid place-items-center text-[10px]">✓</span>
                {c}
              </div>
            ))}
          </div>
        </aside>

        <div className="lg:col-span-8">
          <div className="rounded-3xl glass-strong border-iris p-8 lg:p-10 shadow-elevated space-y-6">
            <Field label="Título da vaga" placeholder="Engenheiro(a) de Software Sênior" />
            <Row>
              <SelectField label="Área" options={["Engenharia", "Design", "Produto", "Dados", "DevOps", "Mobile"]} />
              <SelectField label="Senioridade" options={["Estágio", "Júnior", "Pleno", "Sênior", "Lead/Staff"]} />
            </Row>
            <Row>
              <SelectField label="Modalidade" options={["Remoto", "Híbrido", "Presencial"]} />
              <Field label="Localização" placeholder="São Paulo, SP" />
            </Row>
            <Row>
              <Field label="Salário mínimo (R$)" placeholder="18000" type="number" />
              <Field label="Salário máximo (R$)" placeholder="25000" type="number" />
            </Row>

            <div>
              <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">Stack & tecnologias</label>
              <div className="rounded-xl bg-white/[0.03] border border-white/10 p-3 flex flex-wrap gap-2">
                {tags.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1 text-[12px] font-mono px-2.5 py-1 rounded-md bg-primary/15 border border-primary/30 text-primary-glow">
                    {t}
                    <button onClick={() => setTags(tags.filter((x) => x !== t))} className="hover:text-foreground">×</button>
                  </span>
                ))}
                <input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && tagInput.trim()) { setTags([...tags, tagInput.trim()]); setTagInput(""); } }}
                  placeholder="adicionar e pressionar Enter…"
                  className="flex-1 min-w-[180px] bg-transparent outline-none text-sm placeholder:text-muted-foreground/60"
                />
              </div>
            </div>

            <Field label="Descrição da vaga" textarea placeholder="Contexto, time, problema que vocês resolvem…" />
            <Field label="Responsabilidades (uma por linha)" textarea placeholder="Liderar arquitetura..." />
            <Field label="Requisitos (uma por linha)" textarea placeholder="5+ anos com React..." />
            <Field label="Benefícios (um por linha)" textarea placeholder="PLR semestral..." />

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <Link to="/dashboard/company" className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">cancelar</Link>
              <button onClick={submit} className="inline-flex items-center gap-2 rounded-full bg-gradient-iris px-6 py-2.5 text-sm font-medium text-white shadow-glow">
                Publicar vaga
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ children }: { children: React.ReactNode }) { return <div className="grid sm:grid-cols-2 gap-4">{children}</div>; }
function Field({ label, placeholder, type = "text", textarea }: { label: string; placeholder?: string; type?: string; textarea?: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      {textarea ? (
        <textarea rows={4} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60 resize-none" />
      ) : (
        <input type={type} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60" />
      )}
    </div>
  );
}
function SelectField({ label, options }: { label: string; options: string[] }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      <select className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50">
        {options.map((o) => <option key={o} className="bg-background">{o}</option>)}
      </select>
    </div>
  );
}
