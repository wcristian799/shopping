import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { AmbientBg } from "@/components/cinematic-bg";

export const Route = createFileRoute("/signup/company")({
  head: () => ({ meta: [{ title: "Cadastre sua empresa — bluestack" }] }),
  component: SignupCompany,
});

const steps = ["Identidade", "Cultura", "Equipe", "Plano"] as const;

function SignupCompany() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);

  function next() {
    if (step < steps.length - 1) setStep(step + 1);
    else { toast.success("Empresa cadastrada com sucesso!"); navigate({ to: "/dashboard/company" }); }
  }

  return (
    <div className="relative min-h-screen">
      <AmbientBg />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-12 gap-10">
        <aside className="lg:col-span-4">
          <div className="eyebrow mb-3">empresa · cadastro</div>
          <h1 className="font-display text-5xl lg:text-6xl tracking-tight">Construa um <span className="italic text-gradient-iris">perfil de marca</span>.</h1>
          <p className="mt-4 text-foreground/75 text-sm">Empresas com perfil completo recebem 3.4× mais candidaturas qualificadas.</p>
          <ol className="mt-10 space-y-4">
            {steps.map((s, i) => (
              <li key={s} className="flex items-start gap-3">
                <span className={`mt-0.5 h-7 w-7 grid place-items-center rounded-full text-[11px] font-mono transition-all ${i === step ? "bg-gradient-iris text-white shadow-glow" : i < step ? "bg-success text-black" : "bg-white/5 text-muted-foreground"}`}>
                  {i < step ? "✓" : String(i + 1).padStart(2, "0")}
                </span>
                <div className={`text-sm font-medium ${i === step ? "text-foreground" : "text-muted-foreground"}`}>{s}</div>
              </li>
            ))}
          </ol>
        </aside>

        <div className="lg:col-span-8">
          <div className="rounded-3xl glass-strong border-iris p-8 lg:p-10 shadow-elevated">
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.35 }}>
                {step === 0 && (
                  <div className="space-y-5">
                    <H>Identidade da empresa</H>
                    <Row>
                      <Field label="Nome legal" placeholder="Nebula Tech Ltda" />
                      <Field label="Nome de marca" placeholder="Nebula Tech" />
                    </Row>
                    <Row>
                      <Field label="Website" placeholder="nebula.tech" />
                      <Field label="LinkedIn" placeholder="linkedin.com/company/nebula" />
                    </Row>
                    <Row>
                      <SelectField label="Indústria" options={["SaaS B2B", "Fintech", "AI / ML", "Mobile", "BioTech", "Games"]} />
                      <SelectField label="Tamanho" options={["1-10", "10-50", "50-200", "200-500", "500-1000", "1000+"]} />
                    </Row>
                    <Field label="Logo (URL)" placeholder="https://nebula.tech/logo.svg" />
                  </div>
                )}
                {step === 1 && (
                  <div className="space-y-5">
                    <H>Cultura & missão</H>
                    <Field label="Sua missão em uma frase" placeholder="Empoderar times distribuídos a fazerem o melhor trabalho de suas vidas." />
                    <Field label="O que torna a cultura única" textarea placeholder="Como vocês trabalham? Princípios, rituais, decisões que importam…" />
                    <Field label="Modelo de trabalho padrão" placeholder="Remoto-first com encontros trimestrais" />
                  </div>
                )}
                {step === 2 && (
                  <div className="space-y-5">
                    <H>Pessoa de contato</H>
                    <Row>
                      <Field label="Seu nome" placeholder="Maria Recruiter" />
                      <Field label="Cargo" placeholder="Head of Talent" />
                    </Row>
                    <Row>
                      <Field label="Email corporativo" type="email" placeholder="maria@nebula.tech" />
                      <Field label="Telefone" placeholder="+55 11 90000-0000" />
                    </Row>
                  </div>
                )}
                {step === 3 && (
                  <div className="space-y-5">
                    <H>Escolha um plano</H>
                    <div className="grid sm:grid-cols-3 gap-3">
                      {[
                        { name: "Starter", price: "Grátis", feats: ["1 vaga ativa", "Pipeline básico"] },
                        { name: "Growth", price: "R$ 1.200/mês", feats: ["10 vagas", "Pool de talentos", "Kanban completo"], featured: true },
                        { name: "Scale", price: "Custom", feats: ["Vagas ilimitadas", "ATS completo", "API + SSO"] },
                      ].map((p) => (
                        <div key={p.name} className={`rounded-2xl p-5 transition-all ${p.featured ? "bg-gradient-iris text-white shadow-glow" : "glass-card border border-white/5"}`}>
                          <div className={`text-[10px] font-mono uppercase tracking-[0.22em] ${p.featured ? "text-white/80" : "text-primary-glow"}`}>{p.name}</div>
                          <div className={`mt-2 font-display text-2xl ${p.featured ? "text-white" : ""}`}>{p.price}</div>
                          <ul className={`mt-4 space-y-1.5 text-[12px] ${p.featured ? "text-white/85" : "text-foreground/80"}`}>
                            {p.feats.map((f) => <li key={f}>· {f}</li>)}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="mt-10 flex items-center justify-between">
              <button onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0} className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground disabled:opacity-30">← voltar</button>
              <div className="flex items-center gap-3">
                <Link to="/" className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">cancelar</Link>
                <button onClick={next} className="inline-flex items-center gap-2 rounded-full bg-gradient-iris px-6 py-2.5 text-sm font-medium text-white shadow-glow">
                  {step === steps.length - 1 ? "Criar empresa" : "Continuar"}
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function H({ children }: { children: React.ReactNode }) { return <h2 className="font-display text-3xl tracking-tight mb-2">{children}</h2>; }
function Row({ children }: { children: React.ReactNode }) { return <div className="grid sm:grid-cols-2 gap-4">{children}</div>; }
function Field({ label, placeholder, type = "text", textarea }: { label: string; placeholder?: string; type?: string; textarea?: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      {textarea ? (
        <textarea rows={4} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60 resize-none" />
      ) : (
        <input type={type} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60" />
      )}
    </div>
  );
}
function SelectField({ label, options }: { label: string; options: string[] }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      <select className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50">
        {options.map((o) => <option key={o} className="bg-background">{o}</option>)}
      </select>
    </div>
  );
}
