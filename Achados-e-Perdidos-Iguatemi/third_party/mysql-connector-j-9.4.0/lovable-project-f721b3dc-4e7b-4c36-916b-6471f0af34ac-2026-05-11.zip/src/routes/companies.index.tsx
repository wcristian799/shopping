import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { BrandMark } from "@/components/brand-mark";
import { companies } from "@/lib/mock-data";

export const Route = createFileRoute("/companies/")({
  head: () => ({
    meta: [
      { title: "Empresas tech contratando — bluestack" },
      { name: "description", content: "Conheça as empresas que estão moldando o futuro da tecnologia no Brasil." },
    ],
  }),
  component: CompaniesList,
});

function CompaniesList() {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    if (!q) return companies;
    const s = q.toLowerCase();
    return companies.filter((c) => c.name.toLowerCase().includes(s) || c.industry.toLowerCase().includes(s));
  }, [q]);

  return (
    <div className="relative">
      <AmbientBg />
      <section className="relative pt-20 pb-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="eyebrow mb-3">{companies.length} empresas verificadas</div>
          <h1 className="font-display text-6xl lg:text-7xl tracking-tight">
            Empresas que <span className="italic text-gradient-iris">constroem</span><br />o que vem depois.
          </h1>
          <div className="mt-10 max-w-xl flex items-center gap-3 rounded-2xl glass-strong border-iris px-5 py-3.5">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary-glow" fill="none" stroke="currentColor" strokeWidth={1.8}>
              <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
            </svg>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar empresa ou indústria…" className="flex-1 bg-transparent outline-none text-base" />
          </div>
        </div>
      </section>

      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: (i % 9) * 0.04 }}
              style={{ transform: i % 4 === 1 ? "translateY(1.5rem)" : i % 4 === 3 ? "translateY(-0.5rem)" : undefined }}
            >
              <Link
                to="/companies/$companyId"
                params={{ companyId: c.id }}
                className="group block relative overflow-hidden rounded-3xl glass-card border-iris hover-lift p-6 h-full"
              >
                <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full opacity-50 blur-3xl group-hover:opacity-90 transition-opacity" style={{ background: c.accent }} />
                <div className="relative">
                  <div className="flex items-start justify-between gap-4">
                    <BrandMark initials={c.initials} accent={c.accent} size="xl" />
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-primary-glow">{c.openJobs} vagas</span>
                  </div>
                  <h3 className="mt-5 text-2xl font-medium text-foreground tracking-tight">{c.name}</h3>
                  <div className="mt-1 text-xs text-muted-foreground">{c.industry} · {c.location}</div>
                  <p className="mt-4 text-sm text-foreground/80 line-clamp-3">{c.about}</p>
                  <div className="mt-6 flex items-center justify-between text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
                    <span>fundada {c.founded}</span>
                    <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-success" />{c.size}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
