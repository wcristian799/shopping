import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { Avatar } from "@/components/brand-mark";
import { getCandidate } from "@/lib/mock-data";

export const Route = createFileRoute("/candidates/$candidateId")({
  loader: ({ params }) => {
    const c = getCandidate(params.candidateId);
    if (!c) throw notFound();
    return { candidate: c };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.candidate.name} — ${loaderData.candidate.title}` : "Talento" },
      { name: "description", content: loaderData?.candidate.bio ?? "" },
    ],
  }),
  notFoundComponent: () => (
    <div className="min-h-[60vh] grid place-items-center px-6 text-center">
      <h1 className="font-display text-5xl">Talento não encontrado</h1>
    </div>
  ),
  component: CandidateDetail,
});

const timeline = [
  { year: "2024 — hoje", role: "Senior Engineer", company: "Empresa atual", desc: "Liderou redesign da plataforma core, migração para microserviços, mentor de 4 plenos." },
  { year: "2021 — 2024", role: "Software Engineer", company: "Startup B2B SaaS", desc: "Construiu o sistema de pagamentos do zero, reduziu p99 em 60%." },
  { year: "2018 — 2021", role: "Junior Developer", company: "Consultoria", desc: "Atuou em projetos para clientes enterprise (banco, varejo)." },
];

function CandidateDetail() {
  const { candidate: c } = Route.useLoaderData();

  return (
    <div className="relative">
      <AmbientBg />

      <section className="relative pt-12 pb-12 overflow-hidden">
        <div aria-hidden className="absolute inset-x-0 top-0 h-[440px] -z-10 opacity-50" style={{ background: `radial-gradient(ellipse 70% 80% at 50% 0%, ${c.accent} 0%, transparent 60%)` }} />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-12">
          <Link to="/candidates" className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors">← talentos</Link>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="mt-8 grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-8 flex items-start gap-6">
              <Avatar initials={c.initials} accent={c.accent} size="2xl" />
              <div className="min-w-0">
                <div className="flex items-center gap-3">
                  <h1 className="font-display text-5xl lg:text-6xl tracking-tight">{c.name}</h1>
                  {c.available && (
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-[0.18em] text-success rounded-full glass-card px-3 py-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" /> disponível
                    </span>
                  )}
                </div>
                <div className="mt-2 text-lg text-foreground/85">{c.title}</div>
                <div className="mt-1 text-sm text-muted-foreground">{c.location} · {c.experience} de carreira · {c.workMode}</div>
              </div>
            </div>

            <aside className="lg:col-span-4 rounded-3xl glass-strong border-iris p-6 shadow-elevated">
              <div className="eyebrow">pretensão</div>
              <div className="mt-1 font-display text-4xl text-gradient-iris italic">{c.expectedSalary}</div>
              <button className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-iris py-3.5 text-sm font-medium text-white shadow-glow">
                Convidar para vaga
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
              </button>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
                <a className="rounded-xl bg-white/[0.03] py-2 hover:bg-white/5 transition-colors" href={`mailto:${c.email}`}>email</a>
                <a className="rounded-xl bg-white/[0.03] py-2 hover:bg-white/5 transition-colors" href="#">linkedin</a>
                {c.github && <a className="rounded-xl bg-white/[0.03] py-2 hover:bg-white/5 transition-colors" href="#">github</a>}
              </div>
            </aside>
          </motion.div>
        </div>
      </section>

      <section className="relative pb-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 space-y-12">
            <Block eyebrow="resumo" title="Sobre">
              <p className="text-foreground/85 leading-relaxed text-lg">{c.bio}</p>
            </Block>

            <Block eyebrow="trajetória" title="Linha do tempo">
              <ol className="relative border-l border-white/10 pl-6 space-y-8">
                {timeline.map((t, i) => (
                  <li key={i} className="relative">
                    <span className="absolute -left-[31px] top-1.5 h-3 w-3 rounded-full bg-gradient-iris ring-4 ring-background" />
                    <div className="text-[10px] font-mono uppercase tracking-[0.22em] text-primary-glow">{t.year}</div>
                    <div className="mt-1 text-lg font-medium">{t.role} <span className="text-muted-foreground">· {t.company}</span></div>
                    <p className="mt-2 text-foreground/80 text-sm leading-relaxed">{t.desc}</p>
                  </li>
                ))}
              </ol>
            </Block>
          </div>

          <aside className="lg:col-span-5 space-y-6">
            <Block eyebrow="stack" title="Habilidades">
              <div className="space-y-3">
                {c.skills.map((s: string, i: number) => (
                  <div key={s}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{s}</span>
                      <span className="font-mono text-[11px] text-muted-foreground">{90 - i * 4}%</span>
                    </div>
                    <div className="mt-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <motion.div initial={{ width: 0 }} whileInView={{ width: `${90 - i * 4}%` }} viewport={{ once: true }} transition={{ duration: 1, delay: i * 0.05 }} className="h-full bg-gradient-iris" />
                    </div>
                  </div>
                ))}
              </div>
            </Block>
          </aside>
        </div>
      </section>
    </div>
  );
}

function Block({ eyebrow, title, children }: { eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="eyebrow mb-2">{eyebrow}</div>
      <h2 className="font-display text-3xl tracking-tight mb-5">{title}</h2>
      {children}
    </div>
  );
}
