import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { JobCard } from "@/components/job-card";
import { jobs } from "@/lib/mock-data";

export const Route = createFileRoute("/jobs/")({
  head: () => ({
    meta: [
      { title: "Vagas tech curadas — bluestack" },
      { name: "description", content: "Encontre sua próxima oportunidade nas melhores empresas tech do Brasil." },
    ],
  }),
  component: JobsList,
});

const types = ["Remoto", "Híbrido", "Presencial"] as const;
const levels = ["Estágio", "Júnior", "Pleno", "Sênior", "Lead/Staff"] as const;
const areas = ["Engenharia", "Design", "Produto", "Dados", "DevOps", "Mobile"] as const;
const sorts = ["Mais recentes", "Maior salário", "Mais aplicantes"] as const;

function JobsList() {
  const [q, setQ] = useState("");
  const [type, setType] = useState<string | null>(null);
  const [level, setLevel] = useState<string | null>(null);
  const [area, setArea] = useState<string | null>(null);
  const [sort, setSort] = useState<typeof sorts[number]>("Mais recentes");

  const list = useMemo(() => {
    let l = [...jobs];
    if (q) {
      const s = q.toLowerCase();
      l = l.filter((j) => j.title.toLowerCase().includes(s) || j.company.toLowerCase().includes(s) || j.tags.some((t) => t.toLowerCase().includes(s)));
    }
    if (type) l = l.filter((j) => j.type === type);
    if (level) l = l.filter((j) => j.level === level);
    if (area) l = l.filter((j) => j.area === area);
    if (sort === "Maior salário") l.sort((a, b) => b.salaryMax - a.salaryMax);
    else if (sort === "Mais aplicantes") l.sort((a, b) => b.applicants - a.applicants);
    return l;
  }, [q, type, level, area, sort]);

  return (
    <div className="relative">
      <AmbientBg />

      {/* Hero */}
      <section className="relative pt-20 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-8">
              <div className="eyebrow mb-3">{list.length} vagas abertas · atualizado agora</div>
              <h1 className="font-display text-6xl lg:text-7xl tracking-tight">
                Encontre o trabalho<br />
                <span className="italic text-gradient-iris">que importa</span>.
              </h1>
            </div>
            <div className="lg:col-span-4 text-sm text-muted-foreground">
              Cada vaga é validada manualmente. Sem ruído, sem &quot;cabeças&quot;, sem promessas vazias.
            </div>
          </div>

          {/* Search bar */}
          <div className="mt-10 flex flex-col lg:flex-row gap-3">
            <div className="flex-1 flex items-center gap-3 rounded-2xl glass-strong border-iris px-5 py-3.5">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary-glow" fill="none" stroke="currentColor" strokeWidth={1.8}>
                <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
              </svg>
              <input
                value={q} onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar por cargo, empresa ou stack…"
                className="flex-1 bg-transparent outline-none text-base placeholder:text-muted-foreground"
              />
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as typeof sorts[number])}
              className="rounded-2xl glass-strong border-iris px-4 py-3 text-sm bg-transparent outline-none"
            >
              {sorts.map((s) => <option key={s} value={s} className="bg-background">{s}</option>)}
            </select>
          </div>

          {/* Filters */}
          <div className="mt-6 flex flex-wrap gap-3">
            <FilterGroup label="Modalidade" options={[...types]} value={type} onChange={setType} />
            <FilterGroup label="Senioridade" options={[...levels]} value={level} onChange={setLevel} />
            <FilterGroup label="Área" options={[...areas]} value={area} onChange={setArea} />
            {(type || level || area || q) && (
              <button
                onClick={() => { setType(null); setLevel(null); setArea(null); setQ(""); }}
                className="text-[11px] font-mono uppercase tracking-[0.18em] text-primary-glow hover:text-foreground transition-colors px-3 py-1"
              >
                limpar tudo ×
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {list.length === 0 ? (
            <div className="rounded-3xl glass-card border-iris p-16 text-center">
              <div className="eyebrow mb-3">nenhuma vaga encontrada</div>
              <h3 className="font-display text-3xl">Tente ajustar seus filtros</h3>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {list.map((j, i) => (
                <motion.div
                  key={j.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: (i % 9) * 0.04 }}
                >
                  <JobCard job={j} index={i} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function FilterGroup({
  label, options, value, onChange,
}: { label: string; options: string[]; value: string | null; onChange: (v: string | null) => void }) {
  return (
    <div className="flex items-center gap-1.5 rounded-full glass-card border border-white/5 p-1">
      <span className="px-3 text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      {options.map((o) => {
        const active = value === o;
        return (
          <button
            key={o}
            onClick={() => onChange(active ? null : o)}
            className={`px-3 py-1 rounded-full text-[12px] font-medium transition-all ${
              active ? "bg-gradient-iris text-white shadow-glow-soft" : "text-foreground/75 hover:text-foreground hover:bg-white/5"
            }`}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}
