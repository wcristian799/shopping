import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { AmbientBg } from "@/components/cinematic-bg";

export const Route = createFileRoute("/signup/candidate")({
  head: () => ({ meta: [{ title: "Crie seu perfil — bluestack" }] }),
  component: SignupCandidate,
});

const steps = ["Identidade", "Carreira", "Stack & projetos", "Preferências"] as const;
const SUGGESTED_SKILLS = ["React", "TypeScript", "Node.js", "Python", "Go", "Rust", "AWS", "Kubernetes", "PostgreSQL", "Figma", "Design Systems", "PyTorch", "GraphQL"];

function SignupCandidate() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [skills, setSkills] = useState<string[]>([]);

  function next() {
    if (step < steps.length - 1) setStep(step + 1);
    else { toast.success("Perfil criado! Bem-vinda ao bluestack."); navigate({ to: "/dashboard/candidate" }); }
  }

  return (
    <div className="relative min-h-screen">
      <AmbientBg />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-12 gap-10">
        {/* Left rail */}
        <aside className="lg:col-span-4">
          <div className="eyebrow mb-3">candidato · cadastro</div>
          <h1 className="font-display text-5xl lg:text-6xl tracking-tight">Sua história, <span className="italic text-gradient-iris">bem contada</span>.</h1>
          <p className="mt-4 text-foreground/75 text-sm">4 etapas. Menos de 3 minutos. Você pode editar tudo depois.</p>
          <ol className="mt-10 space-y-4">
            {steps.map((s, i) => (
              <li key={s} className="flex items-start gap-3">
                <span className={`mt-0.5 h-7 w-7 grid place-items-center rounded-full text-[11px] font-mono transition-all ${i === step ? "bg-gradient-iris text-white shadow-glow" : i < step ? "bg-success text-black" : "bg-white/5 text-muted-foreground"}`}>
                  {i < step ? "✓" : String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <div className={`text-sm font-medium ${i === step ? "text-foreground" : "text-muted-foreground"}`}>{s}</div>
                </div>
              </li>
            ))}
          </ol>
        </aside>

        {/* Form */}
        <div className="lg:col-span-8">
          <div className="rounded-3xl glass-strong border-iris p-8 lg:p-10 shadow-elevated">
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.35 }}>
                {step === 0 && (
                  <div className="space-y-5">
                    <H>Quem é você</H>
                    <Row>
                      <Field label="Nome completo" placeholder="Ana Silva" />
                      <Field label="Email profissional" type="email" placeholder="ana@email.com" />
                    </Row>
                    <Row>
                      <Field label="LinkedIn" placeholder="linkedin.com/in/anasilva" />
                      <Field label="GitHub / Portfolio" placeholder="github.com/anasilva" />
                    </Row>
                    <Field label="Headline" placeholder="Engenheira full-stack focada em DX" />
                  </div>
                )}
                {step === 1 && (
                  <div className="space-y-5">
                    <H>Sua trajetória</H>
                    <Row>
                      <Field label="Cargo atual" placeholder="Senior Software Engineer" />
                      <Field label="Empresa atual" placeholder="Nebula Tech" />
                    </Row>
                    <Row>
                      <Field label="Anos de experiência" type="number" placeholder="6" />
                      <SelectField label="Senioridade" options={["Júnior", "Pleno", "Sênior", "Lead/Staff"]} />
                    </Row>
                    <Field label="Resumo profissional" textarea placeholder="Conte sua história em 2-3 parágrafos…" />
                  </div>
                )}
                {step === 2 && (
                  <div className="space-y-5">
                    <H>Stack & projetos</H>
                    <div>
                      <label className="eyebrow">habilidades</label>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {SUGGESTED_SKILLS.map((s) => {
                          const on = skills.includes(s);
                          return (
                            <button
                              key={s}
                              type="button"
                              onClick={() => setSkills((p) => on ? p.filter((x) => x !== s) : [...p, s])}
                              className={`px-3 py-1.5 rounded-full text-[12px] font-mono transition-all ${on ? "bg-gradient-iris text-white shadow-glow-soft" : "bg-white/5 border border-white/10 text-foreground/80 hover:bg-white/10"}`}
                            >
                              {on ? "✓ " : "+ "}{s}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                    <Field label="Projeto destaque (URL)" placeholder="https://…" />
                    <Field label="O que mais te orgulha?" textarea placeholder="Um problema que você resolveu, um sistema que você construiu…" />
                  </div>
                )}
                {step === 3 && (
                  <div className="space-y-5">
                    <H>Preferências</H>
                    <Row>
                      <SelectField label="Modalidade preferida" options={["Remoto", "Híbrido", "Presencial", "Indiferente"]} />
                      <Field label="Cidade" placeholder="São Paulo, SP" />
                    </Row>
                    <Row>
                      <Field label="Pretensão salarial (R$)" placeholder="22000" />
                      <SelectField label="Disponibilidade" options={["Imediata", "30 dias", "60 dias", "Apenas escutando"]} />
                    </Row>
                    <Field label="Tipo de empresa que te interessa" placeholder="Startups B2B SaaS, fintechs em série A…" />
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="mt-10 flex items-center justify-between">
              <button onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0} className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground disabled:opacity-30">← voltar</button>
              <div className="flex items-center gap-3">
                <Link to="/jobs" className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">cancelar</Link>
                <button onClick={next} className="inline-flex items-center gap-2 rounded-full bg-gradient-iris px-6 py-2.5 text-sm font-medium text-white shadow-glow">
                  {step === steps.length - 1 ? "Finalizar perfil" : "Continuar"}
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function H({ children }: { children: React.ReactNode }) { return <h2 className="font-display text-3xl tracking-tight mb-2">{children}</h2>; }
function Row({ children }: { children: React.ReactNode }) { return <div className="grid sm:grid-cols-2 gap-4">{children}</div>; }
function Field({ label, placeholder, type = "text", textarea }: { label: string; placeholder?: string; type?: string; textarea?: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      {textarea ? (
        <textarea rows={4} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60 resize-none" />
      ) : (
        <input type={type} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-colors placeholder:text-muted-foreground/60" />
      )}
    </div>
  );
}
function SelectField({ label, options }: { label: string; options: string[] }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      <select className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50">
        {options.map((o) => <option key={o} className="bg-background">{o}</option>)}
      </select>
    </div>
  );
}
