import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { AmbientBg } from "@/components/cinematic-bg";
import { BrandMark } from "@/components/brand-mark";
import { getCompany, getJob } from "@/lib/mock-data";
import { usePipeline } from "@/store/pipeline-store";

export const Route = createFileRoute("/apply/$jobId")({
  loader: ({ params }) => {
    const job = getJob(params.jobId);
    if (!job) throw notFound();
    return { job, company: getCompany(job.companyId) };
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `Candidatar-se: ${loaderData.job.title}` : "Candidatar-se" }] }),
  notFoundComponent: () => <div className="p-12 text-center">Vaga não encontrada</div>,
  component: ApplyPage,
});

function ApplyPage() {
  const { job, company } = Route.useLoaderData();
  const nav = useNavigate();
  const addApplication = usePipeline((s) => s.addApplication);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    addApplication(job.id, "p1");
    toast.success("Candidatura enviada! Acompanhe pelo painel.");
    nav({ to: "/dashboard/candidate" });
  }

  return (
    <div className="relative min-h-screen">
      <AmbientBg />
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-12 gap-10">
        <aside className="lg:col-span-5">
          <Link to="/jobs/$jobId" params={{ jobId: job.id }} className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">← detalhes da vaga</Link>
          <div className="mt-6 rounded-3xl glass-card border-iris p-6">
            <div className="flex items-start gap-4">
              <BrandMark initials={company?.initials ?? "??"} accent={company?.accent} size="lg" />
              <div className="min-w-0">
                <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-primary-glow">{job.area}</div>
                <h2 className="mt-1 text-xl font-medium leading-tight">{job.title}</h2>
                <div className="mt-1 text-sm text-muted-foreground">{job.company} · {job.location}</div>
              </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Mini label="Salário" value={job.salary} />
              <Mini label="Modalidade" value={job.type} />
              <Mini label="Senioridade" value={job.level} />
              <Mini label="Aplicantes" value={String(job.applicants)} />
            </div>
          </div>
          <div className="mt-6 rounded-3xl glass-card border border-white/5 p-5 text-sm text-foreground/80 space-y-2">
            <div className="eyebrow">o que acontece depois</div>
            <p>1. Sua candidatura aparece no pipeline da empresa em segundos.</p>
            <p>2. Você recebe atualizações por email a cada mudança de estágio.</p>
            <p>3. Em média, empresas respondem em 4 dias úteis.</p>
          </div>
        </aside>

        <form onSubmit={submit} className="lg:col-span-7">
          <div className="rounded-3xl glass-strong border-iris p-8 lg:p-10 shadow-elevated space-y-6">
            <div>
              <div className="eyebrow mb-2">candidatura</div>
              <h1 className="font-display text-4xl tracking-tight">Conte por que <span className="italic text-gradient-iris">você</span></h1>
            </div>

            <Field label="Resposta personalizada" textarea placeholder="Por que esta vaga, esta empresa, neste momento?" />
            <Field label="Pretensão salarial" placeholder="R$ 22.000 / mês" />
            <Field label="Disponibilidade" placeholder="Imediata · 30 dias · 60 dias" />
            <Field label="Link do CV (PDF)" placeholder="https://..." />

            <label className="flex items-start gap-3 text-sm text-foreground/80">
              <input type="checkbox" className="mt-1 accent-primary" defaultChecked />
              <span>Permito que outras empresas verificadas vejam meu perfil neste pool.</span>
            </label>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <Link to="/jobs/$jobId" params={{ jobId: job.id }} className="text-[12px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">cancelar</Link>
              <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-gradient-iris px-6 py-3 text-sm font-medium text-white shadow-glow">
                Enviar candidatura
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}><path d="M5 12h14M13 5l7 7-7 7" /></svg>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/5 p-3">
      <div className="text-[10px] font-mono uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-medium">{value}</div>
    </div>
  );
}
function Field({ label, placeholder, textarea }: { label: string; placeholder?: string; textarea?: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">{label}</label>
      {textarea ? (
        <textarea rows={5} placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 transition-colors placeholder:text-muted-foreground/60 resize-none" />
      ) : (
        <input placeholder={placeholder} className="w-full rounded-xl bg-white/[0.03] border border-white/10 px-4 py-3 text-sm outline-none focus:border-primary/50 transition-colors placeholder:text-muted-foreground/60" />
      )}
    </div>
  );
}
