import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  DndContext, type DragEndEvent, type DragStartEvent, DragOverlay, PointerSensor, useSensor, useSensors,
  useDraggable, useDroppable, closestCorners,
} from "@dnd-kit/core";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { AmbientBg } from "@/components/cinematic-bg";
import { Avatar } from "@/components/brand-mark";
import { getCandidate, getJob, STAGES, type Application, type PipelineStage } from "@/lib/mock-data";
import { usePipeline } from "@/store/pipeline-store";

export const Route = createFileRoute("/dashboard/company/jobs/$jobId")({
  loader: ({ params }) => {
    const job = getJob(params.jobId);
    if (!job) throw notFound();
    return { job };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `Pipeline · ${loaderData.job.title} — bluestack` : "Pipeline" }],
  }),
  notFoundComponent: () => <div className="p-12 text-center">Vaga não encontrada</div>,
  component: KanbanPage,
});

function KanbanPage() {
  const { job } = Route.useLoaderData();
  const allApplications = usePipeline((s) => s.applications);
  const moveApp = usePipeline((s) => s.moveApplication);
  const [activeId, setActiveId] = useState<string | null>(null);

  const applications = useMemo(
    () => allApplications.filter((a) => a.jobId === job.id),
    [allApplications, job.id]
  );

  const byStage = useMemo(() => {
    const map: Record<PipelineStage, Application[]> = {
      applied: [], screening: [], interview: [], tech_test: [], offer: [], hired: [], rejected: [],
    };
    applications.forEach((a) => map[a.stage].push(a));
    return map;
  }, [applications]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  function handleDragStart(e: DragStartEvent) { setActiveId(String(e.active.id)); }
  function handleDragEnd(e: DragEndEvent) {
    setActiveId(null);
    const id = String(e.active.id);
    const overId = e.over?.id ? String(e.over.id) : null;
    if (!overId) return;
    const stage = overId.replace("col-", "") as PipelineStage;
    const current = applications.find((a) => a.id === id);
    if (!current || current.stage === stage) return;
    moveApp(id, stage);
    const stageLabel = STAGES.find((s) => s.id === stage)?.label;
    const cand = getCandidate(current.candidateId);
    toast.success(`${cand?.name ?? "Candidato"} → ${stageLabel}`);
  }

  const activeApp = activeId ? applications.find((a) => a.id === activeId) : null;

  return (
    <div className="relative">
      <AmbientBg />

      <section className="relative pt-12 pb-6">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-8">
          <Link to="/dashboard/company" className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">← painel</Link>
          <div className="mt-6 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div>
              <div className="eyebrow mb-2">pipeline · {applications.length} candidatos</div>
              <h1 className="font-display text-5xl lg:text-6xl tracking-tight">{job.title}</h1>
              <div className="mt-2 text-sm text-muted-foreground">{job.company} · {job.location} · {job.type}</div>
            </div>
            <div className="flex gap-3">
              <Link to="/jobs/$jobId" params={{ jobId: job.id }} className="rounded-full glass-card border border-white/10 px-4 py-2 text-sm hover:bg-white/5">Ver vaga pública</Link>
              <button className="rounded-full bg-gradient-iris px-5 py-2 text-sm font-medium text-white shadow-glow">Convidar candidato</button>
            </div>
          </div>
        </div>
      </section>

      <section className="relative pb-20">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-8">
          <DndContext sensors={sensors} collisionDetection={closestCorners} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
            <div className="flex gap-4 overflow-x-auto scrollbar-thin pb-6">
              {STAGES.map((stage) => (
                <Column key={stage.id} stage={stage} apps={byStage[stage.id]} />
              ))}
            </div>

            <DragOverlay>
              {activeApp ? <CandidateCard app={activeApp} dragging /> : null}
            </DragOverlay>
          </DndContext>
        </div>
      </section>
    </div>
  );
}

function Column({ stage, apps }: { stage: typeof STAGES[number]; apps: Application[] }) {
  const { setNodeRef, isOver } = useDroppable({ id: `col-${stage.id}` });
  return (
    <div
      ref={setNodeRef}
      className={`min-w-[300px] w-[300px] rounded-2xl border transition-all ${isOver ? "border-primary/60 bg-primary/5 shadow-glow" : "border-white/5 bg-white/[0.02]"}`}
    >
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.2em]" style={{ color: stage.tint }}>
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: stage.tint, boxShadow: `0 0 12px ${stage.tint}` }} />
          {stage.label}
        </div>
        <span className="text-[11px] font-mono text-muted-foreground rounded-full bg-white/5 px-2 py-0.5">{apps.length}</span>
      </div>
      <div className="px-3 pb-3 space-y-2 min-h-[300px]">
        <AnimatePresence>
          {apps.map((a) => (
            <motion.div
              key={a.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.25 }}
            >
              <CandidateCard app={a} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

function CandidateCard({ app, dragging }: { app: Application; dragging?: boolean }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: app.id });
  const cand = getCandidate(app.candidateId);
  if (!cand) return null;
  const style = transform ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`group relative rounded-xl glass-strong border-iris p-3 cursor-grab active:cursor-grabbing transition-all ${
        isDragging ? "opacity-30" : ""
      } ${dragging ? "rotate-2 shadow-glow scale-105" : ""}`}
    >
      <div className="flex items-start gap-3">
        <Avatar initials={cand.initials} accent={cand.accent} size="sm" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium truncate">{cand.name}</div>
          <div className="text-[11px] text-muted-foreground truncate">{cand.title}</div>
        </div>
      </div>

      {/* Fit score */}
      <div className="mt-3">
        <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-[0.18em]">
          <span className="text-muted-foreground">match</span>
          <span className="text-primary-glow">{app.fit}%</span>
        </div>
        <div className="mt-1 h-1 rounded-full bg-white/5 overflow-hidden">
          <div className="h-full bg-gradient-iris" style={{ width: `${app.fit}%` }} />
        </div>
      </div>

      {/* Rating + applied */}
      <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
        <div className="flex gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <span key={i} className={`text-[12px] leading-none ${i < app.rating ? "text-warning" : "text-white/15"}`}>★</span>
          ))}
        </div>
        <span className="font-mono">{app.appliedAt}</span>
      </div>

      {app.note && (
        <div className="mt-3 rounded-lg bg-primary/10 border border-primary/20 p-2 text-[11px] text-foreground/80 italic">
          “{app.note}”
        </div>
      )}
    </div>
  );
}
