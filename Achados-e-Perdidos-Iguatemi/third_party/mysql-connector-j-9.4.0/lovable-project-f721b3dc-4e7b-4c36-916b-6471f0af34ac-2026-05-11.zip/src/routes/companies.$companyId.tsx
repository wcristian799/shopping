import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AmbientBg } from "@/components/cinematic-bg";
import { BrandMark } from "@/components/brand-mark";
import { JobCard } from "@/components/job-card";
import { getCompany, jobs } from "@/lib/mock-data";

export const Route = createFileRoute("/companies/$companyId")({
  loader: ({ params }) => {
    const company = getCompany(params.companyId);
    if (!company) throw notFound();
    return { company };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.company.name} — bluestack` : "Empresa" },
      { name: "description", content: loaderData?.company.about ?? "" },
    ],
  }),
  notFoundComponent: () => (
    <div className="min-h-[60vh] grid place-items-center px-6 text-center">
      <div>
        <h1 className="font-display text-5xl">Empresa não encontrada</h1>
        <Link to="/companies" className="mt-6 inline-flex items-center rounded-full bg-gradient-iris px-5 py-2.5 text-sm text-white">Ver todas</Link>
      </div>
    </div>
  ),
  component: CompanyDetail,
});

function CompanyDetail() {
  const { company } = Route.useLoaderData();
  const openJobs = jobs.filter((j) => j.companyId === company.id);

  return (
    <div className="relative">
      <AmbientBg />

      {/* Cinematic header */}
      <section className="relative overflow-hidden pt-10">
        <div
          aria-hidden
          className="absolute inset-x-0 top-0 h-[420px] -z-10 opacity-60"
          style={{ background: `radial-gradient(ellipse 80% 80% at 50% 0%, ${company.accent} 0%, transparent 60%)` }}
        />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 pb-12">
          <Link to="/companies" className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors">
            ← empresas
          </Link>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="mt-8 flex flex-col lg:flex-row lg:items-end gap-8">
            <BrandMark initials={company.initials} accent={company.accent} size="2xl" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3">
                <h1 className="font-display text-6xl lg:text-7xl tracking-tight">{company.name}</h1>
                {company.verified && (
                  <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary-glow/20 text-primary-glow">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={3}><polyline points="20 6 9 17 4 12" /></svg>
                  </span>
                )}
              </div>
              <div className="mt-2 text-muted-foreground">{company.industry} · {company.location} · fundada em {company.founded}</div>
            </div>

            <div className="flex flex-col gap-2 text-right">
              <div className="rounded-2xl glass-strong px-5 py-3 border-iris">
                <div className="eyebrow">vagas abertas</div>
                <div className="font-display text-4xl text-gradient-iris italic">{openJobs.length}</div>
              </div>
            </div>
          </motion.div>

          <div className="mt-10 grid sm:grid-cols-3 gap-4">
            <Stat label="Tamanho" value={`${company.size} pessoas`} />
            <Stat label="Avaliação" value={`★ ${company.rating}`} accent />
            <Stat label="Seguidores" value={company.followers.toLocaleString("pt-BR")} />
          </div>
        </div>
      </section>

      {/* About */}
      <section className="relative pb-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-3 gap-8">
          <Block eyebrow="sobre" title="Quem somos">
            <p className="text-foreground/85 leading-relaxed">{company.about}</p>
          </Block>
          <Block eyebrow="missão" title="Nossa missão">
            <p className="text-foreground/85 leading-relaxed">{company.mission}</p>
          </Block>
          <Block eyebrow="cultura" title="Como trabalhamos">
            <p className="text-foreground/85 leading-relaxed">{company.culture}</p>
          </Block>
        </div>
      </section>

      {/* Open Jobs */}
      <section className="relative pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="eyebrow mb-3">{openJobs.length} oportunidades</div>
          <h2 className="font-display text-4xl tracking-tight mb-8">Vagas em aberto</h2>
          {openJobs.length === 0 ? (
            <div className="rounded-3xl glass-card border border-white/5 p-12 text-center text-muted-foreground">
              Nenhuma vaga aberta no momento.
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {openJobs.map((j, i) => <JobCard key={j.id} job={j} index={i} />)}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl glass-card border border-white/5 p-5">
      <div className="eyebrow">{label}</div>
      <div className={`mt-2 text-2xl font-medium ${accent ? "text-warning" : "text-foreground"}`}>{value}</div>
    </div>
  );
}
function Block({ eyebrow, title, children }: { eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl glass-card border border-white/5 p-6 hover-lift">
      <div className="eyebrow mb-2">{eyebrow}</div>
      <h3 className="font-display text-2xl tracking-tight mb-3">{title}</h3>
      {children}
    </div>
  );
}
