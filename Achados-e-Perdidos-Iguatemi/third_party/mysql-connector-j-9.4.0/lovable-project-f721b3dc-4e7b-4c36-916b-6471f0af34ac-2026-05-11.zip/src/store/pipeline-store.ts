import { create } from "zustand";
import { applications as seedApplications, type Application, type PipelineStage } from "@/lib/mock-data";

type State = {
  applications: Application[];
  moveApplication: (id: string, stage: PipelineStage) => void;
  reorderInStage: (jobId: string, stage: PipelineStage, orderedIds: string[]) => void;
  addApplication: (jobId: string, candidateId: string) => void;
  setNote: (id: string, note: string) => void;
  setRating: (id: string, rating: Application["rating"]) => void;
};

export const usePipeline = create<State>((set) => ({
  applications: [...seedApplications],
  moveApplication: (id, stage) =>
    set((s) => ({ applications: s.applications.map((a) => (a.id === id ? { ...a, stage } : a)) })),
  reorderInStage: (jobId, stage, orderedIds) =>
    set((s) => {
      const affected = s.applications.filter((a) => a.jobId === jobId && a.stage === stage);
      const others = s.applications.filter((a) => !(a.jobId === jobId && a.stage === stage));
      const sorted = orderedIds
        .map((id) => affected.find((a) => a.id === id))
        .filter(Boolean) as Application[];
      return { applications: [...others, ...sorted] };
    }),
  addApplication: (jobId, candidateId) =>
    set((s) => {
      if (s.applications.some((a) => a.jobId === jobId && a.candidateId === candidateId)) return s;
      const newApp: Application = {
        id: `a-${Date.now()}`,
        jobId, candidateId,
        stage: "applied", appliedAt: "agora",
        rating: 0, fit: 60 + Math.floor(Math.random() * 30),
      };
      return { applications: [...s.applications, newApp] };
    }),
  setNote: (id, note) =>
    set((s) => ({ applications: s.applications.map((a) => (a.id === id ? { ...a, note } : a)) })),
  setRating: (id, rating) =>
    set((s) => ({ applications: s.applications.map((a) => (a.id === id ? { ...a, rating } : a)) })),
}));
